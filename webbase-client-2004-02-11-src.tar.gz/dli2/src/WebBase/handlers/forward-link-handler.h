/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Handler for generating forward link index (phase 1)
 *
 * Taher Haveliwala (taherh@cs.stanford.edu)
 */

#ifndef __FORWARD_LINK_HANDLER__
#define __FORWARD_LINK_HANDLER__

/*
 * Subhandler of LinkHandler
 *
 * Process links for the purpose of generating a forward link index
 */

#include "linkhandler.h"

#include "confloader.h"
#include "url2hash.h"
#include "utils/linkswriter.h"

class ForwardLinkHandler : public LinkHandler {
 public:
  ForwardLinkHandler() {
    linksWriter = NULL;
    sourceHash = 0;
  }

  void Init() {
    const char* linksDir = conf.getValue("FLINKS_DIR");
    if (!linksDir) {
      cerr << "Value of parameter FLINKS_DIR not available" << endl;
      exit(0);
    }
    linksWriter = new LinksWriter(linksDir, "links", false);
  }

  void NewSource(string url, string time, int docid,
		 unsigned long long reppos) {
    sourceHash = url2hash(url);
    links.clear();
  }
  void NewDestination(string url) {
    if(sourceHash > 0)
      links.push_back(url2hash(url));
  }
  void EndSource() {
    if (sourceHash > 0) linksWriter->writeLink(sourceHash, links);
    sourceHash = 0;
  }
  void Finish() {}
  ~ForwardLinkHandler() {
    delete linksWriter;
  }

 private:
  LinksWriter* linksWriter;
  unsigned long long sourceHash;
  vector<unsigned long long> links;
};

#endif // __FORWARD_LINK_HANDLER_H__
