/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Driver for list of handlers that webcat driver should invoke
 *  based on ../inputs/webbase.conf <handler>_ON flag
 */


/*
 * To add a new handler, add the following to the appropriate places:
 * 1) #include "myhandler.h"
 * 2) if(!strcmp(conf.getValue("MY_ON"), "1")) handler.push_back(new MyHandler());
 * 3) hmm...have to add some things MyHandler.o to the makefile too.

 * OR run ../scripts/addHandler.pl
 *
 */

#ifndef __ALL_HANDLERS_H__
#define __ALL_HANDLERS_H__

#include <vector>

#include "handler.h"
#include "cat-handler.h"
//#include "splitup-cat-handler.h"
#include "filter-url-handler.h"
#include "offset-handler.h"
#include "pagelength-handler.h"
#include "forward-link-handler.h"
//#include "page-handler.h"
#include "wordstats-handler.h"
#include "linkparser.h"
#include "linkhandler.h"
#include "cat-links.h"
//#include "extract-hosts.h"
#include "urllist.h"
#include "confTable.h"
extern vector<Handler*> handlers;

/* 
   To add a new handler, #include the appropriate file and 
   add the handler entry between "BEGIN_HANDLERS" and "END_HANDLERS"
*/


inline 
int InitHandlers()
{
  //
  // if the format of the following lines changes, change addHandler.pl
  //
  // --- BEGIN HANDLERS
  if(!strcmp(conf.getValue("CAT_ON"     ), "1")) handlers.push_back( new Cat());
  if(!strcmp(conf.getValue("FILTER_ON"  ), "1")) handlers.push_back( new FilterUrlHandler(conf.getValue("FILTER_URLS")) );
  if(!strcmp(conf.getValue("OFFSETS_ON" ), "1"))  handlers.push_back( new Offsets());
  if(!strcmp(conf.getValue("SIZES_ON"   ), "1"))  handlers.push_back( new PageLength());
  //if(!strcmp(conf.getValue("PAGE_ON"     ), "1")) handlers.push_back( new Page());  
 // if(!strcmp(conf.getValue("SPLIT_CAT_ON"), "1")) handlers.push_back( new SplitCat()); 
  //if(!strcmp(conf.getValue("WORDSTATS_ON"   ), "1"))  handlers.push_back( new WordStats());
  // --- END HANDLERS

  LinkParser *linkParser = new LinkParser;

  // BEGIN HANDLERS (link handlers only)
  if(!strcmp(conf.getValue("CATLINKS_ON"), "1")) linkParser->addLinkHandler(new CatLinks);
  if(!strcmp(conf.getValue("URLLIST_ON" ), "1")) linkParser->addLinkHandler(new URLList);
  if(!strcmp(conf.getValue("FLINKS_ON"   ), "1")) linkParser->addLinkHandler( new ForwardLinkHandler());
  //  if(!strcmp(conf.getValue("HOSTS_ON"   ), "1")) linkParser->addLinkHandler( new ExtractHosts());

  // END HANDLERS (link handlers only)

  if (linkParser->getNumLinkHandlers() > 0)
    handlers.push_back(linkParser);
  else
    delete linkParser;

  // Init()'s all handlers
  vector<Handler*>::iterator iter;
  for(iter = handlers.begin(); iter != handlers.end(); iter++) {
    (*iter)->Init();
  }
  return 1;
}

inline
int FinishHandlers() {
  // Finish()'es all handlers
  vector<Handler*>::iterator iter;
  for(iter = handlers.begin(); iter != handlers.end(); iter++) {
    (*iter)->Finish();
  }
  return 1;
}

inline
int InvokeHandlers(string& buffer, string url, string time, 
		   int docid, unsigned long long offset)
{
   vector<Handler*>::iterator iter;
   for( iter = handlers.begin(); iter != handlers.end(); iter++) {
     (*iter)->Process(buffer, url, time, docid, offset);
   }
   return 0;
}



#endif // __ALL_HANDLERS_H__
