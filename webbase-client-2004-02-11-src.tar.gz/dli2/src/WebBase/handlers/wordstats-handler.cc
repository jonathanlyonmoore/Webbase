/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/* 
 * wordstats-handler.cc
 *
 * Computes word statistics
 *
 * Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <iomanip>
#include <fstream>
#include <strstream>
#include <map>
// #include <hash_map>
#include <math.h>

#include "wordstats-handler.h"
#include "common.h"
#include "url2hash.h"
#include "HTML2Plain.h"
#include "confTable.h"

void WordStats::Init() {
  cerr << "initializing wordstats-handler" << endl;
   
  // load up list of terms to pay attention to
  ifstream input(conf.getValue("WORDSTATS_LEXICON"));
  
  string word;
  while(input >> word) {
    keep[word] = true;
  }

  // open output stream for stats
  output.open(conf.getValue("WORDSTATS_OUT"));
  if(!output) {
    cerr << "Couldn't open " << conf.getValue("WORDSTATS_OUT") << endl;
  }

}

void WordStats::Finish() {
  return;
   
  // iterate through counts and output
  map<string, int>::iterator iter;
  for(iter = total_freq.begin(); iter != total_freq.end(); iter++) {
    if(iter->second > 1) 
      output << iter->first << "\t" << iter->second << endl;
  }
}

void WordStats::Process(const string& html, string url, string time, 
		       int docid, unsigned long long offset) {
  // return if we have no place to write output
  if(!output) return;

  // convert page to plain text
  char* plaintext = new char[html.size()+1];
  HTML2Plain::convert(html.c_str(), plaintext);
  
  // scan through words and keep word statistics
  istrstream page(plaintext);

  map<string, int> freq;
  unsigned int count = 0;

  string word;
  while(page >> word) {
    //    if(keep.find(word) == keep.end()) 
      freq[word]++;
      //    total_freq[word]++;
      //    count++;
  }
  
  double doclength = 0;
  
  // calculate document length
  map<string, int>::iterator iter;
  for(iter = freq.begin(); iter != freq.end(); iter++) {
    double w_dt = 1 + log(static_cast<double>(iter->second));
    w_dt = w_dt*w_dt;
    doclength += w_dt;
  }

  doclength = sqrt(doclength);

  output << setfill('0') << setw(20) << url2hash(url) << "\t" << doclength << endl;
  
  /*
  // output header
  output << url << endl;
  output << loseSlash(url2hash(url)) << endl;
  output << count << endl;
  // iterate through counts and output
  map<string, int>::iterator iter;
  for(iter = freq.begin(); iter != freq.end(); iter++) {
    output << iter->first << "\t" << iter->second << endl;
  }

  // output record separator
  output << endl;
  */

  delete [] plaintext;

}
