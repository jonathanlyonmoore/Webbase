/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*                         WebBase project
 *                         ---------------
 *                     
 * Interface for writing url hashes AND OFFSETs to 10 bucket files.
 *      
 * Author: Gary Wesley - gary@db.stanford.edu
 */
#include <fstream.h>
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>
#include <ctype.h>
#include <vector.h>
#include <unistd.h>
#include <getopt.h>

#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <string.h>
#include <math.h>
#include <strstream.h>
#include <assert.h>

#include "offsetwriter.h"

OffsetWriter::OffsetWriter(const char* offsetsDir, const char *baseFilename)
{
  if (!initFiles(offsetsDir, baseFilename )) {
    cerr << "OffsetWriter couldn't define files, exiting" << endl;
    exit(1);
  }
}

bool OffsetWriter::initFiles(const char* offsetsDir, const char *baseFilename )
{
  // open the NUM_OFFSET_BUCKETS bucket files. buf is 2*MAX_LINE+2 so it can hold
  // directory, optional /, filebase, and 2 digit suffix.

  for (int i = 0; i <= NUM_OFFSET_BUCKETS - 1; i++) {
    char buf[2*MAX_LINE+2];

    ostrstream fname(buf, 2*MAX_LINE+2);
    fname << offsetsDir << '/' << baseFilename << setfill('0') << setw(2) << i << ends;
    //cout << "Opening file: " << buf << endl;
    files[i].open(buf);
    if (!files[i].is_open()) {
      cerr << "Could not open file: " << buf << endl;
      return false;
    }
  }

  return true;
}

// Writes a offset to the appropriate file/bucket as determined by the last digit 
// in the hash.

bool OffsetWriter::writeOffset(const  unsigned long long  pageOffset, const unsigned long long  urlHash ) { 
  if( urlHash != 0 ){
    int fileIndex;
    fileIndex = urlHash >> SHIFTFACTOR ; // 0 to 7
    //cout << "urlH " << urlHash << " fileIndex= " << fileIndex << endl;
    
    assert( fileIndex < NUM_OFFSET_BUCKETS && fileIndex >= 0);
    
    ostream& file =files[   fileIndex ];
    file << setfill('0') << setw(20) << urlHash << "\t" << pageOffset << endl;
    if (file.fail()) {
      cerr << "Couldn't write offset and hash to bucket  " <<  fileIndex << endl;
      return false;
    }
    return true;
  }
  else {
    cerr << "0url";    
    return false;
  }

}
