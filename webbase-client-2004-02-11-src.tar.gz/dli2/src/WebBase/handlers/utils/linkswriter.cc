/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*                         WebBase project
 *                         ---------------
 *                     
 * Interface for writing links output by webcat to a file
 *
 * Author: Taher H. Haveliwala - taherh@cs.stanford.edu
 */

#include <iostream.h>
#include <fstream.h>
#include <vector.h>
#include <assert.h>
#include <strstream.h>
#include <iomanip.h>

#include "linkswriter.h"
#include "Utils.h"

#define ASSERT assert

LinksWriter::LinksWriter(const char* linksdir, const char* baseFilename,
			 bool append0) {
  append = append0;
  if(!createFileTable(linksdir, baseFilename)) {
    cerr << "Exiting..." << endl;
    exit(1);
  }
}

bool
LinksWriter::createFileTable(const char* linksdir, const char* baseFilename) {
  // now open the corresponding files
  // buf is 2*MAX_LINE+2 so it can hold
  //             directory, optional /, filebase, and 2 digit suffix
  int i;
  for(i = 0; i < 256; i++) {
    char buf[2*MAX_LINE+2];

    ostrstream fname(buf, 2*MAX_LINE+2);
    fname << linksdir;
    if(linksdir[strlen(linksdir)-1] != '/') {
      fname << '/';
    }
    fname << baseFilename << "." << setfill('0') << setw(3) << i << ends;
    if (append) {
      cerr << "Appending to file: " << buf << endl;
      files[i].open(buf, ios::app);
    }
    else {
      cerr << "Opening file: " << buf << endl;
      files[i].open(buf);
    }

    if(!files[i].is_open()) {
      cerr << "Could not open file: " << buf << endl;
      return false;
    }
  }
  return true;
}

bool
LinksWriter::writeLink(unsigned long long sourceId, 
		       vector<unsigned long long int>& destIds) {
  ostream& file = getFileFor(sourceId);
  
  //  unsigned long long sourceId = Utils::htonll(sourceId);
  file.write((char*) &sourceId, sizeof(sourceId));
  
  unsigned long long size = destIds.size();
  // FIXME
  file.write((char*) &size, sizeof(size));

  unsigned long long dest;
  vector<unsigned long long int>::iterator iter;

    for(iter = destIds.begin(); iter != destIds.end(); iter++) {
      dest = *iter;
      file.write((char*) &dest, sizeof(dest));
    }

    if(file.fail()) {
      cerr << "Couldn't write link" << endl;
      return false;
    }
    return true;
}

ofstream&
LinksWriter::getFileFor(unsigned long long id) {
  int whichFile = id >> 56;
  ASSERT(whichFile < 256 && whichFile >= 0);
  return  files[whichFile];
}

