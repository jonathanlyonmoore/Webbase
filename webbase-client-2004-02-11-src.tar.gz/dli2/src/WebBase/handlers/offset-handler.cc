/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 *  Handler for offsets index
 *
 * Author: Gary Wesley <gary@db.stanford.edu> 3/01
 * Version: 2.1
 */

#include "offset-handler.h"

//#include "webbase.h"  // global webbase defs

Offsets::Offsets( ){cout << "Offsets()"  << endl; 
   recoverable_error   = false;
   unrecoverable_error = false;

   
   offsetsDir = conf.getValue((char * ) "OFFSETS_SCRATCH"); // new in 2.1
   if (! offsetsDir) {
     cerr << "Value of parameter OFFSETS_SCRATCH not available" << endl;
     recoverable_error = true;
     return;
   }    
   cout << "outputting to directory " << offsetsDir << endl; 
   //offsetsDir= "."; 
    offsetWriter = new OffsetWriter( offsetsDir, "offsets" );
 
}

Offsets::~Offsets(){ cout << "Offsets::~Offset" << endl;  }


void  Offsets::Init() {  cout << "Offsets::Init()" << endl; }

void  Offsets::Finish() {  
  offsetsFile.close();  cout <<  "Offsets::finish()" << "  offsetsFile.close()" << endl; 
}


//
// Do the actual work
//

void  Offsets::Process(const string& html, string url, string time, 
		       int docid, unsigned long long offset) {
   if(offset < 0){ 
    cerr << "NEGATIVE offset " << offset << endl << url ;
    cerr << " Maybe it should be " << (signed long long) offset << endl;
    offset = 0;
    if((signed long long) offset > 0){
      cerr << "fixed it!";
      offsetWriter->writeOffset( (signed long long) offset,  url2hash(url) );
    }

  }
  //cout <<  url2hash(url) << " from " <<  url << '\t' << offset << endl;
   else 
     // cout << offset  << " " << (signed long long) offset << endl; 
  
  // offsetsFile << setfill('0') << setw(20) <<  url2hash(url) << "\t" << offset << endl;
    offsetWriter->writeOffset(  offset,  url2hash(url) );

}
