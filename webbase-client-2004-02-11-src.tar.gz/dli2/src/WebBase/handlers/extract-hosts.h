/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef _EXTRACT_HOSTS_H_
#define _EXTRACT_HOSTS_H_

#include <string>
#include <iostream>

#include <WWWCore.h>
#include <HTParse.h>

#include "linkparser.h"

class ExtractHosts : public LinkHandler {
  string srcHost;
  map<string, int> hosts;

 public:
  ExtractHosts() { }

  void Init() {
    count = 0;
  }

  void NewSource(string url, string time, int docid,
		   unsigned long long reppos) {
    char* host = HTParse(url.c_str(), NULL, PARSE_HOST);
    srcHost = host;
    delete [] host;
  }
  
  int count;
  void NewDestination(string url) {
    if(count > 0 && count % 10000 == 0) {
      OutputHosts();
    }
    char* host = HTParse(url.c_str(), NULL, PARSE_HOST);
    if(srcHost != host)
      hosts[host]++;
    delete [] host;
  }

  void EndSource() {}
  
  void Finish() {
    OutputHosts();
  }

  void OutputHosts() {
    map<string, int>::iterator iter;
    for(iter = hosts.begin(); iter != hosts.end(); iter++) {
      cout << iter->first << "\t" << iter->second << endl;
    }
    hosts.clear();
  }
};

#endif


