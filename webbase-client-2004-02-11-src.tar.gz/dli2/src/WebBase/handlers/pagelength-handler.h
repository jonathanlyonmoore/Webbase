/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 *  Handler for pageLength index
 *
 * Author: Gary Wesley <gary@db.stanford.edu> 4/01
 */
//#define onlyHTML          // compile switch for count HTML (fast) or not (slow)
#ifndef __pageLength_H
#define __pageLength_H

#include <fstream.h>
#include <iostream.h>
#include <iomanip.h>
#include "confloader.h"
#include "pagelengthwriter.h"
#include "url2hash.h"      
#include "normalize.h"     
#include "handler.h"     
#include <string>
#include "HTML2Plain.h"  // for counting non-HTML bytes
#include "confTable.h"   // new in 2.1
//#define noHTML

class PageLength : public Handler {
 private:
  int debug;

  char pageLengthFileName[MAX_LINE_LENGTH]; 
  const char * pageLengthDir;
  static const char *  const fileName = "/pageLength";

  static const int typicalHeaderLength = 195;  // to guess # chars in no-body page in all mode

  PagelengthWriter *pagelengthWriter;    // pointer to a size/urls writer class

  static const int CRAWL_MAX_BYTES = 1310720; // crawler only gets this many bytes/page
  
 public:
  PageLength( );
  ~PageLength();
  void Init() ;
  void Finish();
  
  void Process( const string& html, string url, string time, 
	       int docid, unsigned long long offset);
  inline bool robotText(string& url);
};
#endif
