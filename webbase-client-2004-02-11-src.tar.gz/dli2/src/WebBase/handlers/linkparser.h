/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Link parser absorbs Web pages and invokes link handlers on its hyperlinks
 * Wang Lam <wlam@cs.stanford.edu> 28 Feb 2001
 *
 */

#ifndef _LINKPARSER_H_
#define _LINKPARSER_H_

#include "handler.h"
#include "linkhandler.h"

#include <string>
#include <vector>
#include "html_parser.h"
#include "url.h"

class LinkParser : public Handler {
   public:
      void addLinkHandler(LinkHandler *lh) {
         linkHandlers.push_back(lh); lh->Init();
      };
      unsigned int getNumLinkHandlers() const { return linkHandlers.size(); };

      void Init();
      void Process(const string& page, string url, string time, int docid,
                       unsigned long long reppos);
      void Finish();

   private:
      vector<LinkHandler*> linkHandlers;
      html_parser parser;
      url baseURL, destinationURL;
};

#endif // _LINKPARSER_H_

