/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*                         WebBase project
 *                         ---------------
 *                     
 * Interface for writing urls and their hashes to 64 bucket files.
 * The breakpoints file (which is one of the parameters required to instantiate
 * this class) must contain 63 urls (one per url) based on which the urls
 * will be assigned to the buckets.
 *      
 * Author: Sriram Raghavan - rsram@cs.stanford.edu
 */

#include <iostream.h>
#include <iomanip.h>
#include <fstream.h>
#include <string.h>
#include <strstream.h>
#include <stdlib.h>

#include "urlwriter.h"

UrlWriter::UrlWriter(const char* urlsDir, const char *baseFilename, const char *breakpointFile) 
{
  if (!initFiles(urlsDir, baseFilename, breakpointFile)) {
    cerr << "UrlWriter couldn't open breakpointfile. Exiting..." << endl;
    exit(1);
  }
}

bool UrlWriter::initFiles(const char* urlsDir, const char *baseFilename, const char *brkptFile)
{
  // open the 64 bucket files. buf is 2*MAX_LINE+2 so it can hold
  // directory, optional /, filebase, and 2 digit suffix.

  for (int i = 0; i < 64; i++) {
    char buf[2*MAX_LINE+2];

    ostrstream fname(buf, 2*MAX_LINE+2);
    fname << urlsDir << '/' << baseFilename << setfill('0') << setw(2) << i << ends;
    cerr << "Opening file: " << buf << endl;
    files[i].open(buf);
    if (!files[i].is_open()) {
      cerr << "Could not open file: " << buf << endl;
      return false;
    }
  }

  // Open the break point file and read in the 63 breakpoint url's into
  // the array to be used for binary search

  ifstream bpfile(brkptFile);
  for (int i = 0; i < 63; i++) {
    bpfile.getline(breaks[i], MAX_LINE_LENGTH);
    if (bpfile.fail() || bpfile.eof()) {
      cerr<< "Couldn't read the breakpoint file" << endl;
      return false;
    }
  }
  return true;
}

// Writes a url to the appropriate file/bucket as determined by the characters 
// in the url. Currently the hash value is not being used even though it is 
// being passed as a parameter.

bool UrlWriter::writeUrl(const char *url, const unsigned long long hash) {
  ostream& file = getFileFor(url);
  file << url << endl;
  if (file.fail()) {
    cerr << "Couldn't write url and hash to bucket - " << url << endl;
    return false;
  }
  return true;
}

// Returns the file to which the given url (and it's hash) are to be written. This
// is decided based on the url's read from the breakpoints file

ofstream& UrlWriter::getFileFor(const char *url) {
  // Handle the special cases when the url has to go into the first or the last bucket

  if (strcmp(url, breaks[62]) > 0) return files[63];
  if (strcmp(url, breaks[0]) <= 0) return files[0];

  // Do binary search to locate the right index. If the url exactly matches with the ith
  // breakpoint (i = 0..62), then it is placed in the ith file (i=0..62).

  int mid, low = 0, high = 62;
  while (high-low > 1) {
    mid = (low + high)/2;
    if (strcmp(url, breaks[mid]) == 0) return files[mid];
    if (strcmp(url, breaks[mid]) < 0) {
      if (strcmp(url, breaks[mid-1]) > 0) return files[mid];
      high = mid;
    }
    else low = mid;
  } 
  if (strcmp(url, breaks[low]) <= 0) return files[low];
  return files[high];
}
