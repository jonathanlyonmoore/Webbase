#include <jni.h>
#include "webbase_feeders_RepositoryFeeder.h"
#include "Feeder.h"
#include "WebCatFeeder.h"

static WebCatFeeder* wcf;

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _open
 * Signature: (Ljava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_webbase_feeders_RepositoryFeeder__1open
  (JNIEnv * env, jobject, jstring feederURI)
{
  const char* cstr_uri = env->GetStringUTFChars(feederURI, 0);
  wcf = new WebCatFeeder(string(cstr_uri));
  env->ReleaseStringUTFChars(feederURI, cstr_uri);
  return true;
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _seek
 * Signature: (J)Z
 */
JNIEXPORT jboolean JNICALL Java_webbase_feeders_RepositoryFeeder__1seek
  (JNIEnv *, jobject, jlong offset)
{
  return wcf->seek(offset);
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _next
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_webbase_feeders_RepositoryFeeder__1next
  (JNIEnv *, jobject)
{
  return wcf->next();
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _getData
 * Signature: ()[B
 */
JNIEXPORT jbyteArray JNICALL Java_webbase_feeders_RepositoryFeeder__1getData
  (JNIEnv * env, jobject)
{
  int size = wcf->getDataSize();
  jbyteArray r = env->NewByteArray(size);
  env->SetByteArrayRegion(r, 0, size, (jbyte*) wcf->getData());
  return r;
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _getURL
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_webbase_feeders_RepositoryFeeder__1getURL
  (JNIEnv * env, jobject)
{
  return env->NewStringUTF(wcf->getURL());
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _getOffset
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_webbase_feeders_RepositoryFeeder__1getOffset
  (JNIEnv *, jobject)
{
  return wcf->getOffset();
}

/*
 * Class:     webbase_feeders_RepositoryFeeder
 * Method:    _getTimestamp
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_webbase_feeders_RepositoryFeeder__1getTimestamp
  (JNIEnv * env, jobject)
{
  return env->NewStringUTF(wcf->getTimestamp());
}
