#include <jni.h>
#include "webbase_feeders_NetworkFeeder.h"
#include "Feeder.h"
#include "NetworkFeeder.h"

static NetworkFeeder* nwf;

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _open
 * Signature: (Ljava/lang/String;I)Z
 */
JNIEXPORT jboolean JNICALL Java_webbase_feeders_NetworkFeeder__1open
  (JNIEnv * env, jobject, jstring hostname, jint port)
{
  const char* cstr_hostname = env->GetStringUTFChars(hostname, 0);
  nwf = new NetworkFeeder(cstr_hostname, port, -1, false);
  env->ReleaseStringUTFChars(hostname, cstr_hostname);
  return nwf->isInitialized();
}

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _next
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_webbase_feeders_NetworkFeeder__1next
  (JNIEnv *, jobject)
{
  return nwf->next();
}

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _getData
 * Signature: ()[B
 */
JNIEXPORT jbyteArray JNICALL Java_webbase_feeders_NetworkFeeder__1getData
  (JNIEnv * env, jobject)
{
  int size = nwf->getDataSize();
  jbyteArray r = env->NewByteArray(size);
  env->SetByteArrayRegion(r, 0, size, (jbyte*) nwf->getData());
  return r;
}

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _getURL
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_webbase_feeders_NetworkFeeder__1getURL
  (JNIEnv *env, jobject)
{
  return env->NewStringUTF(nwf->getURL());
}

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _getOffset
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_webbase_feeders_NetworkFeeder__1getOffset
  (JNIEnv *, jobject)
{
  return nwf->getOffset();
}

/*
 * Class:     webbase_feeders_NetworkFeeder
 * Method:    _getTimestamp
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_webbase_feeders_NetworkFeeder__1getTimestamp
  (JNIEnv * env, jobject)
{
  return env->NewStringUTF(nwf->getTimestamp());
}
