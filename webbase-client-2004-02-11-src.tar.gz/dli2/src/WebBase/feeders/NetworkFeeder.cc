/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/******************************************************************************
 *                          NetworkFeeder
 * 
 * Implements the Feeder interface and acts as client of the Distributor to
 * receives pages across the network.
 *
 * Author : Sriram Raghavan <rsram@cs.stanford.edu>
 *****************************************************************************/

#include "NetworkFeeder.h"
#include "FeederParams.h"
#include "Utils.h"
#include "Url.h"
#include "repository.h"
#include <algorithm>
#include <iostream.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <netdb.h>
#include <zlib.h>

NetworkFeeder::NetworkFeeder(string feederURI)
{
  // Parse uri and check the scheme
  Url::ParsedUrl url(feederURI);
  string scheme = url.getScheme();
  std::transform(scheme.begin(), scheme.end(), scheme.begin(), ToLower());
  if (scheme != "net") {
    cerr << "NetworkFeeder: uri scheme is not 'net'" << endl;
    initialized = false;
    return;
  }

  // Extract parameters and call the initialization function
  string hostname = url.getNetworkLocation().getHost();
  int port = atoi(url.getNetworkLocation().getPort().c_str());
  Url::NVMap queryParams = url.getQueryParameters();
  initialize(hostname.c_str(), port, FeederParams::numPages(queryParams), 
             FeederParams::compress(queryParams));
}


void NetworkFeeder::initialize(const char *hostname, int port, int numPages, bool compress)
{
  cerr << "Instantiating NetworkFeeder to connect to " << hostname << " at " << port << endl;

  initialized = false;
  
  buffer = new char[MAX_FILE_SIZE+1];
  url = new char[MAX_URL_SIZE+1];
  timeStamp = new char[TIMESTAMP_LENGTH+1];
  incomingBuffer = new char[2*MAX_FILE_SIZE + 1];


  count = numPages;
  incomingDocType = outgoingDocType = 0;
  this->compress = compress;
  timeStamp[0] = '\0';
  url[0] = '\0';
  buffer[0] = '\0';
  pageSize = 0;

  // Create socket
  if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    perror("NetworkFeeder-Unable to create socket");
    return;
  } 
  struct sockaddr_in serv_addr;
  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port =  htons(port);
  struct hostent *hp;
  if ( (hp = gethostbyname(hostname)) == NULL) {
    perror("NetworkFeeder-Cannot resolve hostname");
    return;
  }
  // changed from bcopy
  memcpy((char *)&serv_addr.sin_addr, hp->h_addr, hp->h_length);

  // Attempt to connect to remote server
  if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
    perror("NetworkFeeder-No connection to server");
    return;
  }

  // Send out the count of the number of pages requested
  int net_Count;
  Utils::writeNumber((char *)&net_Count, (const char *)&count, sizeof(count));
  if (! Utils::writen(sockfd, (char *)&net_Count, sizeof(net_Count))) {
    perror("NetworkFeeder-Unable to write the page count to the socket");
    return;
  }

  // Read the incoming document type value
  if (! Utils::readn(sockfd, (char *)&incomingDocType, sizeof(incomingDocType))) {
    perror("NetworkFeeder-Unable to read DocType from socket");
    return;
  }

  // Set the outgoing document type
  if (compress) outgoingDocType = incomingDocType | COMPRESSED_TYPE;
  else outgoingDocType = incomingDocType & ~COMPRESSED_TYPE;  

  signal(SIGPIPE, SIG_IGN);     // to prevent "Broken pipe"'s when server shuts down
  initialized = true;
}

NetworkFeeder::~NetworkFeeder() {
  delete [] buffer;
  delete [] url;
  delete [] timeStamp;
  delete [] incomingBuffer;
}

bool NetworkFeeder::next()
{
  if ( (!initialized) || (count == 0)) return(false);   // count = 0 => required number of pages fed already

  DocIdType net_docId;
  int net_pageSize;
  int urlLen, net_urlLen, tsLen, net_tsLen;
  unsigned long long net_offset;


  // Read docid, offset, timestamp length, url length, and page length from the socket
  if (! Utils::readn(sockfd, (char *)&net_docId, sizeof(net_docId)) ||
      ! Utils::readn(sockfd, (char *)&net_offset, sizeof(net_offset)) ||
      ! Utils::readn(sockfd, (char *)&net_tsLen, sizeof(net_tsLen)) ||
      ! Utils::readn(sockfd, (char *)&net_urlLen, sizeof(net_urlLen)) ||
      ! Utils::readn(sockfd, (char *)&net_pageSize, sizeof(net_pageSize)) ) {
    cerr << "NetworkFeeder : Error reading from socket, probably connection closed" << endl;
    close(sockfd); 
    return(false);
  }
  Utils::readNumber((const char *)&net_docId, (char *)&docId, sizeof(docId));
  Utils::readNumber((const char *)&net_offset, (char *)&offset, sizeof(offset));
  Utils::readNumber((const char *)&net_tsLen, (char *)&tsLen, sizeof(tsLen));
  Utils::readNumber((const char *)&net_urlLen, (char *)&urlLen, sizeof(urlLen));
  Utils::readNumber((const char *)&net_pageSize, (char *)&incomingPageSize, sizeof(incomingPageSize));
  
  // If url, timestamp, or page is too long, panic and close connection. This should not 
  // happen, since the distributor and webcatfeeder also use the same buffer sizes.
  if ((tsLen > TIMESTAMP_LENGTH) || (urlLen > MAX_URL_SIZE) || (incomingPageSize > MAX_FILE_SIZE)) {
    cerr << "NetworkFeeder: Panic!! received extra long buffer, url, or timestamp. Quitting " << endl;
    close(sockfd);
    return(false);
  }

  // Read the timestamp from the socket  
  if (! Utils::readn(sockfd, timeStamp, tsLen)) {
    cerr << "NetworkFeeder : Error reading timestamp from socket, probably connection closed" << endl;
    close(sockfd); 
    return(false);
  }

  // Read the url from the socket  
  if (! Utils::readn(sockfd, url, urlLen)) {
    cerr << "NetworkFeeder : Error reading url from socket, probably connection closed" << endl;
    close(sockfd); 
    return(false);
  }

  // Read page and compress or uncompress as required
  if (doUncompression() || doCompression()) {
    if (! Utils::readn(sockfd, incomingBuffer, incomingPageSize)) {
      cerr << "NetworkFeeder : Error reading page from socket, probably connection closed" << endl;
      close(sockfd); 
      return(false);
    } 
    incomingBuffer[incomingPageSize] = '\0';
    unsigned long lpageSize= 2*MAX_FILE_SIZE;
    int status;
    if (doUncompression())
      status = uncompress((unsigned char *)buffer, &lpageSize, (unsigned char *)incomingBuffer, incomingPageSize);
    else
      status = ::compress((unsigned char *)buffer, &lpageSize, (unsigned char *)incomingBuffer, incomingPageSize);
    if (status != Z_OK) {
      cerr << "NetworkFeeder: Uncompression error. Status = " << status << endl;
      pageSize = 0;
    } 
    else pageSize = (int)lpageSize;
  }

  // No need to either compress or decompress. Just read from network into buffer
  else {
    pageSize = incomingPageSize;
    if (! Utils::readn(sockfd, buffer, pageSize)) {
      cerr << "NetworkFeeder : Error reading page from socket, probably connection closed" << endl;
      close(sockfd); 
      return(false);
    }
  }

  url[urlLen] = '\0';
  buffer[pageSize] = '\0';
  timeStamp[tsLen] = '\0';
  if (count != -1) count--;
  return(true);
}
