/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*                         WebBase project
 *                         ---------------
 * This "hash" function computes a 64-bit hash of a "normalized "url. 
 * Note : requires the use of non-ANSI "unsigned long long int" data type to
 *        get support for 8byte integers. The GNU g++ compiler only provides
 *        4byte long ints.
 * Author : Sriram Raghavan  -   rsram@cs.stanford.edu
 */

#ifndef __URLHASH_H_
#define __URLHASH_H_

#include "Crc64.h"
#include "Crc32.h"

/* Hashes the url present in the buffer "url" to a 64-bit integer. Makes a simple
 * call to the Compute function defined in the Crc64 class. Returns an unsigned 
 * long long int.
 */
unsigned long long hash64(char *url);

/* Hashes the URL pointed to by "url". Separately hashes the server portion
 * of the URL (no end '/' is included in the server portion) into a 32-bit 
 * CRC and the rest of the URL (if it exists) into another 32-bit CRC. The
 * two are then merged together (with the server portion of the URL 
 * occupying the high-order 32 bits) into a 64bit int and returned
 */
unsigned long long hash3232(char *url);

#endif
