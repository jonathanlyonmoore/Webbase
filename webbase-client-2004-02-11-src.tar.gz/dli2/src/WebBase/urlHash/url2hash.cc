/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/* url2hash.cc
 *
 * Go from a url to a WebBase hash id
 *
 */

#include <iostream>
#include <cstdlib>

#include "normalize.h"
#include "url2hash.h"
#include "urlHash.h"

using std::string;

unsigned long long url2hash(string url) {
  char* s = strdup(url.c_str());
  if(s != NULL) {
    // return url2hash(s);
    unsigned long long hashvalue = url2hash(s);
    free(s);
    return(hashvalue);
  }
  else {
    return 0;
  }
}

// returns the id on success, 0 on failure
// the probability of a valid url having the 
// crc value of 0 is negligible (1 / 2^64)
unsigned long long url2hash(char* url) {
  normalize(url);
  size_t len = strlen(url);
  unsigned long long r;
  if(len < 11) return 0;
  if(strncmp(url, "http://", 7)) return 0;
  bool trail = false;
  if(url[len-1] == '/') {
     trail = true;
     url[len-1] = '\0';
  }
  r = hash64(url);
  if(trail) {
     url[len-1] = '/';
     r |= 0x0000000000000001ULL;
  }
  else {
     r &= 0xFFFFFFFFFFFFFFFEULL;
  }
  return r;
}

