/*
   minidelta.c - a simple delta-encoding-compression filter
   Wang Lam <wlam@cs.stanford.edu>
   February 1999

   Delta compression takes a stream of lines, sorted in some dictionary
   order, and compresses each line by omitting the longest prefix (substring)
   that it shares with the line prior in the stream.

   This code additionally supports occasional "checkpointing," in which
   a line is not compressed at all (its longest prefix is defined as zero)
   to provide an occasional reference line for later strings in the stream.

   Usage: deltafilter (lines per forced checkpoint)
   where (lines per forced checkpoint) is a positive integer,
   or zero if one desires no forced checkpoints.

   In a run over a million sorted uniq'd URLs (50MB), checkpoints every
   hundred lines consumes about 4% more disk space than no forced
   checkpoints at all.
*/


#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "normalize.h"		/* defines MAX_LINE_LENGTH */

int main(int argc, char *argv[])
{
	int linesPerReset = 0;		/* lines until forced reset */
	int lines=0;			/* lines processed since reset */

	char buffer[MAX_LINE_LENGTH] = {0};	/* incoming string */
	char last[MAX_LINE_LENGTH] = {0};	/* last compressed string */
	size_t count;				/* characters that match */

	/* Process argument */
	if (argc > 1) {
		linesPerReset = atoi(argv[1]);
	} else {
		fprintf(stderr,"Usage: %s number-of-lines-per-reset (0--no resets)\n", argv[0]);
		return 1;
	}

	/* Filter-compress the input */
	while(fgets(buffer,MAX_LINE_LENGTH,stdin)) {
		size_t len;	/* holds strlen(buffer) (minor optimization) */
		len = strlen(buffer);
		if (buffer[len-1] == '\n')
			buffer[len-1]='\0';
		else
		{
			char excess[MAX_LINE_LENGTH];
			fprintf(stderr,"Error: Line exceeded %d characters!\n",
				MAX_LINE_LENGTH);
			fprintf(stderr,"error: string truncated\n");
			fprintf(stderr,"error: string was %s",buffer);
			do {
				fgets(excess,MAX_LINE_LENGTH,stdin);
				fputs(excess,stderr);
			} while (excess[strlen(excess)-1] != '\n');
		}

		++lines;
		if (lines == linesPerReset) {
			fputs("0 ",stdout);
			puts(buffer);
			strcpy(last,buffer);
			lines = 0;
			continue;
		}

		count = 0;
		while ((buffer[count] == last[count]) && (last[count] != '\0'))
			++count;

		printf("%d ",count);
		puts(buffer + count);

		strcpy(last+count,buffer+count);
		last[len-1] = '\0';
	}
	return 0;
}

