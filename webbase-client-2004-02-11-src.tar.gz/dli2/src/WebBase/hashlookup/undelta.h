/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   undelta.h - a simple delta-encoding-decompression class
   Wang Lam <wlam@cs.stanford.edu>
   February 1999

   Delta compression takes a stream of lines, sorted in some dictionary
   order, and compresses each line by omitting the longest prefix (substring)
   that it shares with the line prior in the stream.

   This class provides a simple facility for undoing delta compression.
*/

#ifndef _UNDELTA_H
#define _UNDELTA_H

/* CountingType is the type used to represent the prefix length shared
   between consecutive strings.  (See delta.h.)
   To be safe, choose at least as a large an integer type as was used in the
   corresponding delta compression, or to be precise, choose an integer type 
   large enough to hold the largest shared prefix length to be seen.
*/
template <class CountingType>
class DeltaDecode {
   public:
      DeltaDecode();

      /*
       * Decompresses a delta-compressed string, screaming onto cerr if
       * an error occurs (e.g., a given sublen is impossibly high).
       * sublen - the shared-prefix length
       * s - the prefix-compressed string (s[0] = '\0' if the string is empty)
       *     never send s==NULL
       * returns the decompressed string, which should be delete[]'d when done
       */
      char *expand(CountingType sublen, const char *s);

      /* clean up, BUG FIX by Sergey Melnik */
      /* Bug fix renamed from cleanup() to ~DeltaDecode (class destructor).
         (Thanks, Sergey, for catching this!) Jan 2000 <wlam@cs.stanford.edu> */
      ~DeltaDecode();
      
protected:
      char *lastString;
};
      
#include "undelta.cc"
#endif
