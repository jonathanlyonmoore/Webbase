/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   delta.cc - a simple delta-encoding class
   Wang Lam <wlam@cs.stanford.edu>
   February 1999
*/

#include <iostream.h>
#include <string.h>

/* Warning: Use of <string.h> hazardous to very very long strings.
   In particular, strings longer than max(size_t) chars long will
   break strlen().
*/

template<class CountingType>
DeltaEncode<CountingType>::DeltaEncode(unsigned long checkpointsize) : 
      totalBytesIn(0), totalBytesOut(0),
      linesSinceCheckpoint(0), linesBetweenCheckpoints(checkpointsize),
      lastString(new char[1]), reportDeltaOverflow(false)
{
   *lastString = '\0';
}

template<class CountingType>
DeltaEncode<CountingType>::~DeltaEncode()
{
   delete [] lastString;
}

template<class CountingType>
CountingType DeltaEncode<CountingType>::delta(const char *s)
{
   // Check the argument
   if (s == NULL) {
      cerr << "Error: Internal error in DeltaEncode::delta caller" << endl;
      cerr << "error: string pointer s in DeltaEncode::delta [" 
           << __FILE__ << ':' << __LINE__ << ']' << endl;
      cerr << "error: is NULL (but shouldn't be)" << endl;
      return 0;
   }

   // Delta-encode the argument
   CountingType compress = findDelta(lastString,s);
//   cerr << "Debug: bytesSinceReset = " << bytesSinceReset << endl;
//   bytesSinceReset += sizeof(CountingType) +
//                      sizeof(char)*strlen(&s[compress]) +
//                      sizeof('\0') /* == sizeof(char) in C++ */; 

   // Do we need a checkpoint?
//   if (bytesSinceReset > bytesPerReset) {
//      bytesSinceReset = sizeof(CountingType) +
//                        sizeof(char)*strlen(s) + sizeof('\0');
//      compress = 0;
//   }
   if (linesBetweenCheckpoints) {
      ++linesSinceCheckpoint;
      if (linesSinceCheckpoint > linesBetweenCheckpoints) {
         linesSinceCheckpoint = 0;
         compress = 0;
      }
   }

   // Record some statistics
   totalBytesIn += strlen(s) + sizeof('\0');
   totalBytesOut += sizeof(CountingType) +
                    sizeof(char)*strlen(&s[compress]) +
                    sizeof('\0');

   // Save string s as new last string
   delete lastString;
   lastString = new char[strlen(s)+1];
   strcpy(lastString,s);

   return compress;
}

template <class CountingType>
CountingType DeltaEncode<CountingType>::findDelta(const char *s1,const char *s2)
{
   if (s1 == NULL) {
      cerr << "Error: Internal error in DeltaEncode::findDelta caller" << endl;
      cerr << "error: string pointer s1 in DeltaEncode::findDelta [" 
           << __FILE__ << ':' << __LINE__ << ']' << endl;
      cerr << "error: is NULL (but shouldn't be)" << endl;
      return 0;
   }
   if (s2 == NULL) {
      cerr << "Error: Internal error in DeltaEncode::findDelta caller" << endl;
      cerr << "error: string pointer s2 in DeltaEncode::findDelta [" 
           << __FILE__ << ':' << __LINE__ << ']' << endl;
      cerr << "error: is NULL (but shouldn't be)" << endl;
      return 0;
   }

   CountingType ret = 0;
   while (s1[ret] == s2[ret]) {
      if (s1[ret] == '\0')
         break;
      if ( ((CountingType) (ret+1)) <= ret) {
         if (reportDeltaOverflow) {
            cerr << "Note: Common substring length exceeds type maximum ["
                 << __FILE__ << ':' << __LINE__ << ']' << endl;
            cerr << "note: findDelta parameters:" << endl
                 << "note: " << s1 << endl
                 << "note: and" << endl
                 << "note: " << s2 << endl;
         }
         break;
      }
      ret = ret + 1;
   }
   return ret;
}

