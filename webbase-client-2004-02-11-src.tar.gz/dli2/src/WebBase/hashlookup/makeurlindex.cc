/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   makeurlindex.cc - Generates files containing offsets into the URL list
   Wang Lam <wlam@cs.stanford.edu>
   March 1999

   Takes input files of delta-encoded strings, and compiles an index for
   them based on their hash as defined by HASH() == url2hash().
   (Until March 2001, the hash was defined by urlHash/urlHash.h:hash64().)
   The index is a list of number pairs, (hash) + ' ' + (offset) + \n,
   where (hash) is a HASH() of a delta-decoded string, and (offset) is
   the ftell() offset of the nearest-but-not-past checkpoint from which
   one can eventually delta-decode the URL whose HASH() is (hash).

   (That is, the only real guarantee is that (1) one can begin delta-decoding
   from a given (offset), and (2) if one delta-decodes from the (offset),
   one will eventually stumble across a line whose HASH() matches (hash).)

   If multiple input file support is enabled, the index becomes
   (hash) + ' ' + (file#) + ' ' + (offset) + \n, where (file#) is the 
   number of the source file where the URL was found and for which (offset)
   applies.  The number counts from 0, and is assigned to the files in the
   order they appear on the command line.

   The files created, outdir/urlindex{000..255} form the index.  The number
   000..255 represents the value of the highest eight bits of the hashes
   contained within that file.  (This makes later sorting easier.)

   (This modification, from using 6 bits to get 00..63, was applied
   January 2000 <wlam@cs.stanford.edu>.)

   Usage: makeurlindex outdir inputfile
    outdir      directory where to create urlindex000 .. urlindex255 files
    inputfiles  file(s) containing delta-encoded strings
                   unless multiple input file support is enabled,
                   only one file may be specified

   This code takes about 90-120 minutes to churn through 1.3GB of delta-encoded
   URLs on a 512MB-RAM dual-Pentium-II-Klamath at load 2-3, r/w on ext2fs
   (pita.stanford.edu).
*/

#define MULTIPLE_INPUT       // Enable multiple input file support

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <csignal>
#include "undelta.h"
#include "normalize.h"
#if 0
   #include "urlHash.h"
   #define HASH (hash64)      // The hash function to use
#else
   #include "url2hash.h"
   #define HASH (url2hash)    // The hash function to use
#endif

using std::cout;
using std::cerr;
using std::endl;
using std::ofstream;

typedef unsigned short int CountType;
#ifndef MAX_NUM_LENGTH
#define MAX_NUM_LENGTH (7) // Provides space for delta-compression line prefix
#endif

/*  Currently unused... to be maintained by main() for to-be-written
    signal(siginfo) handler if needed.
unsigned long processed_bytes = 0;
unsigned int file_number = 0;
*/

int main(int argc, char *argv[])
{
   if (argc < 3) {
      cerr << "Fatal: Usage: " << argv[0] << " outdir inputfile(s)" << endl;
      cerr << "fatal:    outdir is a directory where files urlindex%2d will be created"
           << endl
           << "fatal:    inputfile(s) specify files of delta-encoded strings"
           << endl;
      return 1;
   }
#ifndef MULTIPLE_INPUT
   if (argc > 3) {
      cerr << "Fatal: Sorry, multiple input files are not supported." << endl
           << "fatal: Please recompile with MULTIPLE_INPUT to enable support."
           << endl;
      return 1;
   } 
#endif
   if (strlen(argv[1]) > MAX_LINE_LENGTH - strlen("/urlindex000") - 1)
   {
      cerr << "Fatal: Output directory argument is too long a string." << endl;
      cerr << "fatal: Please shorten and try again." << endl;
      return 1;
   }

   // Open all 256 output files
   ofstream *outfile[256] = { NULL };
   char *pattern;	// for sprintf
   if (argv[1][strlen(argv[1])-1] == '/')
      pattern = "%surlindex%03d";
   else
      pattern = "%s/urlindex%03d";
   int i;
   for (i = 0; i < 256; ++i)
   {
      char outname[MAX_LINE_LENGTH];
      sprintf(outname,pattern,argv[1],i);
      outfile[i] = new ofstream(outname);
      if (outfile[i]->fail()) {
         perror("Error: Cannot open output file");
         return 2;
      }
   }

   // Loop through each input file
   for (int infile = 0; infile < argc-2; ++infile)
   {
      // Allow one byte for input file number
      if (infile > 255) {
         fprintf(stderr,"Error: Too many (more than 255) input files\n");
         break;
      }

      // Open the input file
      FILE *fin = fopen(argv[infile+2],"rt");
      if (fin==NULL) {
         fprintf(stderr,"Error: Can't open file %s:",
            argv[infile]);
         perror("");
         continue;
      }

      // Loop through each line of the file
      DeltaDecode<CountType> decoder;
      unsigned long cur_checkpt = 0;
      char str[MAX_LINE_LENGTH+MAX_NUM_LENGTH];
      CountType len; 
      while(1) {

         // Check our position as we read the line
         unsigned long cur_pos = ftell(fin);
         if (cur_pos == -1)
            perror("Error: Cannot get file position from ftell()");
         int in_len;
         if (fscanf(fin,"%ud",&in_len) == EOF)
            if (feof(fin))
            {
               fprintf(stderr,"Note: End of input file %d\n",infile);
               break; // out of input
            }
            else
               fprintf(stderr,"Error: Line format improper for delta-compressed data\n");
         len = (CountType) in_len;
         if (len != in_len)
            fprintf(stderr,"Error: Internal error: "
               "incorrect CountType in makeurlindex.cc\n");
         fgetc(fin);
         fgets(str,MAX_LINE_LENGTH+MAX_NUM_LENGTH,fin);
         while (str[strlen(str)-1] != '\n' && !feof(fin)) {
            fprintf(stderr,"Error: Line too long!\n");
            fgets(str,MAX_LINE_LENGTH+MAX_NUM_LENGTH,fin);
         }
         str[strlen(str)-1] = '\0';

         // Adjust our nearest checkpoint
         if (len == 0) cur_checkpt = cur_pos;

         // Delta-decode the string and hash it
         char *out = decoder.expand(len,str);
         unsigned long long h = HASH(out);
         delete [] out;

         // Record the index entry (hash, (optional file#), file offset)
         // ideally, in the right bucket
//         cout << '(' << len << ") " << out << ' ' << str << ' ';
//         cout << h << " " << cur_checkpt << endl;
         (*outfile[(unsigned)(h>>(64-8))]) 
                                << h << ' ' 
#ifdef MULTIPLE_INPUT
                                << infile << ' '
#endif
                                << cur_checkpt << endl;
      }
      fclose(fin);
   }

   for (i = 0; i < 256; ++i)
      outfile[i]->close();
   return 0;
}
