/*
   cutter.c - break a long stream of output into multiple files
   Wang Lam <wlam@cs.stanford.edu>
   February 1999

   This program takes on standard input a stream of lines, each line no
   longer than MAX_LINE_LENGTH, and writes them out to files.
   The stream may be of arbitrary length, and will be redirected into
   one file until it exceeds a certain size.  Then, the program will attempt
   to open a next file and redirect output there, and so on.

   Modified 22 Jan 2000 <wlam@cs.stanford.edu>:
   cutter now enumerates the files it writes starting with zero, rather than
   starting with one.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "normalize.h"

#ifndef MAX_LINE_LENGTH
#define MAX_LINE_LENGTH (1024+1)
#endif

#define MAX_NUM_LENGTH (7)	// Max length of ASCII rep of # of chars shaved

int main(int argc, char *argv[])
{
	unsigned long cutoff = 0;		/* bytes until cutoff */
	unsigned long counter = 0;		/* bytes so far */

	char filenames[MAX_LINE_LENGTH];	/* pattern for filenames */
	char filename[MAX_LINE_LENGTH];		/* current filename */
	unsigned int filenumber = 0;		/* which # file are we on? */
	FILE *handle = NULL;

	char line[MAX_LINE_LENGTH + MAX_NUM_LENGTH];	/* input */

	/* Process argument */
	if (argc > 1) 
		cutoff = atoi(argv[1]);
	else
		cutoff = 0;
	if (!cutoff) {
		fprintf(stderr,"Usage: cutter bytes-before-cutoff [scanf-filename-mask]\n");
		fprintf(stderr,"Default scanf-filename-mask: file%%d\n");
		fprintf(stderr,"bytes-before-cutoff must be nonzero\n");
		return 1;
	}
	/* fprintf(stderr,"Files to be cut after %d bytes\n",cutoff); */

	if (argc > 2)
		strcpy(filenames,argv[2]);
	else
		strcpy(filenames,"file%d");


	/* Open the first file */
	sprintf(filename,filenames,filenumber);
	handle = fopen(filename,"w");
	if (handle == NULL) {
		perror("Can't open file");
		return 2;
	}

	/* Copy stdin to handle */
	while (fgets(line,MAX_LINE_LENGTH+MAX_NUM_LENGTH,stdin)) {
		size_t len = strlen(line);
		counter += len;
		/* Match a new breakpoint to a new file */
		if ((strncmp(line,"0 ",2) == 0) && (counter > cutoff)) {
			/* safe breakpoint for new file */
			fclose(handle);
			++filenumber;
			counter = len;
			sprintf(filename,filenames,filenumber);
			fprintf(stderr,"Note: Opening new file %s\n",filename);
			handle = fopen(filename,"w");
			if (handle == NULL) {
				sprintf(line,"Can't open %s",filename);
				perror(line);
				return 2;
			}
		}
		fputs(line,handle);
                if(line[len-1] != '\n') {
                   fprintf(stderr,"Warning: Input line exceeds %d chars\n",
                      MAX_LINE_LENGTH+MAX_NUM_LENGTH);
                }
	}

	return 0;
}
