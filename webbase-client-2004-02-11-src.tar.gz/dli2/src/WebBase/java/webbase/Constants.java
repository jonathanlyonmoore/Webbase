/*
 * Constants.java
 *
 */

package webbase;

/** 
 * Constants contains various constants used by WebBase 
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public interface Constants {
    public static final String DELIMITER = "==P=>>>>=i===<<<<=T===>=A===<=!Junghoo!==>";
}    
