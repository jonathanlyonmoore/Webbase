/*
 * RunHandlers.java
 *
 */

package webbase.handlers;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Properties;

import webbase.Constants;
import webbase.feeders.Feeder;

/**
 * Invokes a set of document handlers over a stream of pages supplied by a
 * feeder.
 * 
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public class RunHandlers implements Constants {
    private Feeder feeder = null;
    private List handlers = new LinkedList();

    /**
     * Construct a RunHandlers driver backed by a feeder
     */
    public RunHandlers(Feeder feeder) {
	this.feeder = feeder;
    }

    /**
     * Add a document handler
     */
    public void addHandler(Handler handler) {
	handlers.add(handler);
    }

    /**
     * Remove a document handler
     */
    public void removeHandler(Handler handler) {
	handlers.remove(handler);
    }

    /**
     * Start the driver loop
     */
    public void processPages() {
	while(feeder.next()) {
	    Iterator iter = handlers.iterator();
	    while(iter.hasNext()) {
		((Handler) iter.next()).
		    processPage(feeder.getData(),
				feeder.getURL(),
				feeder.getOffset(),
				feeder.getTimestamp(),
				feeder.getAllProperties());
	    }
	}
    }
}
