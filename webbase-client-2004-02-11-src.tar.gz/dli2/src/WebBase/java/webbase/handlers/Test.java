/*
 * Test.java
 *
 */

package webbase.handlers;

import webbase.feeders.RepositoryFeeder;

/**
 * Test out the handlers functionality
 *
 * @author Taher H. Haveliwala
 */
public class Test {
    public static void main(String[] args) {
	if(args.length != 1) {
	    System.err.println("Usage: java webbase.handlers.Test repname");
	    System.err.println("Hint: you really want repname to be /afs/ir/class/cs276a/data1/stanford.edu/rep-stanford");
	    System.exit(1);
	}
	RepositoryFeeder r = new RepositoryFeeder(args[0]);
	if(!r.seek(0)) {
	    System.err.println("Couldn't seek to beginning of file");
	    System.exit(1);
	}
	RunHandlers rh = new RunHandlers(r);
	rh.addHandler(new CatHandler());
	rh.processPages();
    }
}
