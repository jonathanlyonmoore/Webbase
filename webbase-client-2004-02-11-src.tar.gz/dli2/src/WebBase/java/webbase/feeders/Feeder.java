/*
 * Feeder.java
 *
 * Feeder interface
 *
 * Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
 *         (Adapted from WebBase code pieces)
 */

package webbase.feeders;

import java.util.Properties;

import webbase.Constants;


/**
 * Abstract interface to Feeders.  A Feeder provides access to a set of web
 * pages using a pull-style iterative interface.
 *
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public interface Feeder extends Constants {

    /**
     * increment the iterator
     *
     * @return true if successful, false if there is no more data
     */
    public boolean next();

    /**
     * retrieve the current page as a byte array
     */
    public byte[] getData();

    /**
     * retrieve the current page as a String
     */
    public String getDataString();

    /**
     * returns just the HTML page, excluding the HTTP headers
     */
    public String getPageString();
    /**
     * retrieve the URL of the current page
     */
    public String getURL();
    
    /**
     * retrieve the offset of the current page
     */
    public long getOffset();

    /**
     * retrieve the timestamp associated with the current page
     */
    public String getTimestamp();

    /**
     * retrieve other properties that may or may not be available
     */
    public String getProperty(String key);

    /**
     * retrieve the properties 
     */
    public Properties getAllProperties();
    
    /**
     * seek to the specified offset
     */
    public boolean seek(long offset);
}
