/*
 * RepositoryFeeder.java
 *
 * Provides access to web page repositories
 *
 * Currently a non-native implementation.  Uses the WebBase c++ code via JNI.
 *
 * Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
 *         (Adapted from WebBase code)
 *
 */

package webbase.feeders;

import java.util.Properties;

/**
 * RepositoryFeeder provides access to pages from a locally stored crawl.
 * Currently, the stanford.edu crawl is available as 
 * /afs/ir/class/cs276a/data1/stanford.edu/rep-stanford
 *
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public class RepositoryFeeder implements Feeder {
    private static final String NATIVE_LIBRARY = "repository";

    private native boolean _open(String feederURI);
    private native boolean _seek(long pos);
    private native boolean _next();
    private native byte[] _getData();
    private native String _getURL();
    private native long _getOffset();
    private native String _getTimestamp();
  
    static {
	//	System.err.println(System.getProperty("java.library.path"));
	System.loadLibrary(NATIVE_LIBRARY);
    }

    /**
     * initialize the feeder
     * Since this invokes a native library, if repname doesn't exist,
     * bad things will happen.
     */
    public RepositoryFeeder(String repname, String sitesfile) {

	_open(root, sitesfile);
    }

    /**
     * goto pos
     */
    public boolean seek(long pos) {

	return _seek(pos);
    }

    /**
     * move to the next record
     */
    public boolean next() {

	return _next();
    }

    /**
     * get the current page as a byte array
     */
    public byte[] getData() {
	return _getData();
    }

    /**
     * get the current page as a String
     */
    public String getDataString() {
	return new String(_getData());
    }

    /**
     * returns just the HTML page, excluding the HTTP headers
     */
    public String getPageString() {
	String s = getDataString();
	int i = s.indexOf("\r\n\r\n");
	if(i < s.length()) {
	    return s.substring(i+4);
	}
	else {
	    return "";
	}
    }

    /**
     * get the URL of the current page
     */
    public String getURL() { 
	return _getURL();
    }

    /**
     * get the offset of the current page
     */
    public long getOffset() { 
	return _getOffset();
    }
    
    /**
     * get the timestamp of the current page
     */
    public String getTimestamp() { 
	return _getTimestamp();
    }

    /**
     * this feeder supports no auxiliary properties
     */
    public String getProperty(String key) {
	return "";
    }

    /**
     * this feeder supports no auxiliary properties
     */
    public Properties getAllProperties() {
	return null;
    }
    
    public static void main(String[] args) {
	if(args.length != 1) {
	    System.err.println("Usage: java webbase.feeders.RepositoryFeeder repname");
	    System.err.println("Hint: you really want repname to be /afs/ir/class/cs276a/data1/stanford.edu/rep-stanford");
	    System.exit(1);
	}
	RepositoryFeeder r = new RepositoryFeeder(args[0]);
	if(!r.seek(0)) {
	    System.err.println("Couldn't seek to beginning of file");
	    System.exit(1);
	}
	while(r.next()) {
	    System.out.println("URL: " + r.getURL());
	    System.out.println("Date: " + r.getTimestamp());
	    System.out.println("Offset: " + r.getOffset());
	    System.out.println();
	    System.out.println(r.getPageString());
	    System.out.println(DELIMITER);
	}
    }
}
