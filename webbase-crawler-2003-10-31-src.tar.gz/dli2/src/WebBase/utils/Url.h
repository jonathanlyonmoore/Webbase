/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*********************************************************************************
 * Defines a bunch of classes to parse and manipulate URLs. Includes support for
 * encoding and decoding URL strings and extracting scheme, host, port, username,
 * password, parameters, and query strings. All classes are defined within the
 * namespace "Url".
 *
 * Adapted by Sriram Raghavan <rsram@cs.stanford.edu> from original implementation
 * by G. Andrew Mangogna. (http://www.slip.net/~andrewm/c++-library/)
 *********************************************************************************/

#ifndef _Url_h_
#define _Url_h_

#include <string>
#include <vector>
#include <map>
#include <stdexcept>

namespace Url {
  using std::string;
  using std::vector;
  using std::map;
  using std::underflow_error;

  class UrlEncoder	{
	public:
		static string encode(const string& s);
		static string decode(const string& s) throw(underflow_error);
    
	private:
		static char toASCII(char c)               { return (c + '0' + (c > 9 ? ('A' - '9' - 1) : 0)); }
		static char fromASCII(char c);
		static const char _nonGraphicMask;
		static const char _unsafeMask;
		static const char _reservedMask;
		static const char _urlCharTypes[256];
	};


	class NetworkLocation {
	public:
		NetworkLocation()                                { }
		NetworkLocation(const string& netlocation)       { parse(netlocation); }

		void parse(const string& netlocation);
		string getEncoded() const;

		const string& getUser() const throw()            { return _user; }
		const string& getPassword() const throw()        { return _password; }
		const string& getHost() const throw()            { return _host; }
		const string& getPort() const throw()            { return _port; }
		void setUser(const string& user) throw()         { _user = user; }
		void setPassword(const string& password) throw() { _password = password;	}
		void setHost(const string& host) throw()         { _host = host; }
		void setPort(const string& port) throw()         { _port = port; }

	private:
		string _user ;
		string _password ;
		string _host ;
		string _port ;
	};


	class UrlPath	{
	public:
		UrlPath(): _leadingSlash(false)                     { }
		UrlPath(const string& path) : _leadingSlash(false)  { parse(path); }

		void parse(const string& path);
		string getEncoded() const;
		string getPathName() const;

		const vector<string>& getComponents() const throw() {	return _pathComponents;		}
		bool getLeadingSlash() const throw()                { return _leadingSlash; }
		void setLeadingSlash(bool leadingSlash) throw()     {	_leadingSlash = leadingSlash; }
		void addComponent(const string& component)          {	_pathComponents.push_back(component);	}

	private:
		bool _leadingSlash ;
		vector<string> _pathComponents ;
	};


  struct nameCompare {
    bool operator()(const string &s1, const string &s2) const 
    { 
      return (s1.compare(s2) < 0); 
    }
  };

  typedef map<const string, string, nameCompare> NVMap;


	class ParsedUrl	{
	public:
		ParsedUrl()                                                { }
		ParsedUrl(const string& url)                               { parse(url); }

		void parse(const string& url);
		string getEncoded() const;
    NVMap getQueryParameters() const;

		const string& getScheme() const throw()                    { return _scheme; }
		const NetworkLocation& getNetworkLocation () const throw() { return _networkLocation;	}
		const UrlPath& getPath() const throw()                     { return _path; }
		const string& getParams() const throw()                    { return _params; }
		const string& getQueryString() const throw()               { return _query; }
		const string& getFragment() const throw()                  { return _fragment; }

	private:
		string _scheme ;
		NetworkLocation _networkLocation ;
		UrlPath _path ;
		string _params ;
		string _query ;
		string _fragment ;
	};
  
};

#endif
