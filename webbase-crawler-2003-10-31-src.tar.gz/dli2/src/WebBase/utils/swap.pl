#!/usr/bin/perl

while(<>) {
    ($a, $b) = split;
    print $b . "\t" . $a . "\n";
}
