/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   neg.cc - Takes a 64-bit decimal integer and returns its signed form
   Wang Lam <wlam@cs.stanford.edu>
   January 2000

   Because of a bug in the interactive MySQL client and the C MySQL
   interface, 64-bit values can be entered into the MySQL database
   signed or unsigned, but queries that match these values must always
   used signed 64-bit integers.

   This program imply takes 64-bit decimal integers on standard input
   as text (one per line), and outputs their signed form on standard
   output one per line, also in decmal text.
*/

#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main(void) {
   unsigned long long i;
   long long j;

   cin >> i;
   while (!cin.fail()) {
      j = i;
      cout << j << endl;
      cout.flush();
      cin >> i;
   }
   return 0;
}
