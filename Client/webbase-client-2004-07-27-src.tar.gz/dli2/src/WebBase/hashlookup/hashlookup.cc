/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   hashlookup.cc - Looks up a WebBase document ID and retrieves its URL
   Wang Lam <wlam@cs.stanford.edu>
   March 1999

   WebBase uses 64-bit hashes as document IDs for internal use, but must
   must convert them back into unique URLs for its results to be meaningful
   to users.

   This program (compiled as a stand-alone filter or as a module in a larger
   WebBase server) uses pre-built indices--a delta-encoded URL list and a
   dense hash index built from it--to provide this hash -> URL lookup service.

   extern unsigned int verbose_errors;

   To turn on verbose error reporting on stderr, set verbose_errors to a
   true (nonzero) value.  To turn it off, set verbose_errors to zero (the
   default).  Messages are prefaced by "Warning: " to indicate an abnormal
   or error condition that does not impair correct operation, or "Error: "
   to indicate an error condition that causes the function to fail.  (There
   are no "Fatal: " messages, in which the code abnormally terminates
   immediately.)  Multi-line error messages have subsequent lines begin
   with "warning: ", "error: ", or "fatal: ", respectively.

   There are only two functions of interest in this code, and they do exactly
   what you think they do.  To fill the details:

   extern "C" { int initialize_hashlookup(const char *indexfilemask,
                                          const char *deltafilemask); }

      indexfilemask is a printf-style format that takes an int (which will
      range 0 - 255) and expands into filenames of less than MAX_LINE_LENGTH
      chars that hold the hash lookup (delta-encoded URL list) indices built
      for WebBase.
      Modified 26 Jan 2000 <wlam@cs.stanford.edu>:
      indexfilemask takes ints 0 - 255, increased from 0 - 63 before.

      deltafilemask, when multiple delta-encoded list support is not
      enabled, is a printf-style format that takes one int, always 0,
      and expands into a filename of less than MAX_LINE_LENGTH chars that holds
      the delta-encoded URL list indexed by the hash lookup indices.

      Modified 22 Jan 2000 <wlam@cs.stanford.edu>:
      deltafilemask, when multiple delta-encoded list support is 
      enabled, is a printf-style format that takes one int, from 0 to 255,
      and expands into n filenames of less than MAX_LINE_LENGTH chars each,
      that hold the delta-encoded URL lists referenced by the hash lookup
      indices.  Multiple-URL-list support is enabled in this code using
      #define MULTIPLE_INPUT, or equivalent.

   must be called first (before hashlookup(), below).  It may be called
   repeatedly as needed (for example, when responding to SIGHUPs in a server
   daemon).

   The function returns 1 if it initializes successfully (in particular, can
   open all the above-named files), and 0 if not.

   extern int hashlookup_error;
   extern "C" { char *hashlookup(unsigned long long hash); }

   retrieves the unique URL associated with a 64-bit hash <hash>, if it
   exists, and malloc()'s (not new[]!) a char[] containing the URL, returning
   the buffer's address as the return value.  If, for some reason, this
   function fails, it will return NULL instead and set hashlookup_error.
   To prevent memory leaks, be sure to free() the returned pointer when
   you are done.

   hashlookup_error takes on one of these values after a hashlookup():
   0   SUCCESS   no error; the lookup was successful and a char* returned
                 This is the only case in which the return value is not NULL.
   1   MEMORY    out of memory (malloc() failed)
   2   FILES     some kind of file error occurred (see errno, stdio.h)
   3   NOHASH    hash does not exist in WebBase
   4   INTERNAL  internal error (program bug of some kind)

   Compiled as a filter program (#define MAIN), you get an executable
   that takes 64-bit hashes as text strings (i.e., printf("%qd",hash))
   one per line, and returns their corresponding URLs, one per line.
   In the event of an error, an error message will be sent to stderr
   instead of a URL to stdout.  This main in particular will strive to
   fflush(stdout) before sending stderr messages so the lines appear in
   the right order.

   Modified 14 Jan 2000 <wlam@cs.stanford.edu>:
   To receive the 64-bit hashes as hexadecimal text (i.e.,
   printf("%qx",hash)) instead, add the argument "hex" (without
   quotation marks) as the third argument to the program.

   Usage: hashlookup indexfilemask lookupfilemask [hex]
   where the first two arguments are the same as in initialize_hashlookup(),
   and the last argument, the literal string "hex", enables hexadecimal text
   input rather than the default decimal text input.
*/

// #define MAIN      // for a standalone compile
#define MULTIPLE_INPUT  // to support indices over multiple URL lists

unsigned int hashlookup_error = 0;
unsigned int verbose_errors = 0;

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <netinet/in.h>
#include "undelta.h"
#include "normalize.h"
#include "hashlookup.h"
#if 0
   #include "urlHash.h"
   #define HASH (hash64)      // The hash function to use
#else
   #include "url2hash.h"
   #define HASH (url2hash)    // The hash function to use
#endif
#include "Utils.h"

typedef unsigned short int CountType;
#ifndef MAX_NUM_LENGTH
#define MAX_NUM_LENGTH (7) // Provides space for delta-compression line prefix
#endif

FILE *indexfile[256] = { NULL };
unsigned long indexfilesize[256] = { 0 };  // count of index_records, not bytes
#ifdef MULTIPLE_INPUT
   FILE *deltafile[256] = { NULL };
#else
   FILE *deltafile = NULL;
#endif

struct index_record {
   unsigned long long docID;
#ifdef MULTIPLE_INPUT
   unsigned long long filenum;
#endif
   unsigned long long offset;
};

/* initialize_hashlookup - closes all the files indexfile[] and deltafile,
   then reopens them using snprintf's of the parameters as filenames.  See
   the comments at the top of this file for details on the parameters.

   Along the way, it makes sure that the index files each has an integral 
   number of index records, a sanity check against file corruption.

   Unimplemented (but necessary in a hostile environment) is a check on
   the function's parameters; it is necessary to ensure that the printf
   masks given take only one sizeof(int) argument each.
*/
int initialize_hashlookup(const char *indexmask, const char *deltamask)
{
   int retvalue = 1;  // assume success

   // Clean up the existing opened files
   if (indexfile[0]) {
      for (int i=0; i < 256; ++i)
         if (indexfile[i])
            fclose(indexfile[i]), indexfile[i]=NULL;
         else if (verbose_errors)
            fprintf(stderr,"Warning: Internal error: Not all indices open.\n");
            
#ifdef MULTIPLE_INPUT
      for (int i=0; i < 256; ++i)
         if (deltafile[i])
            fclose(deltafile[i]), deltafile[i]=NULL;
         else
            fprintf(stderr,
                "Warning: Internal error: Not all delta-encoded files open.\n");
#else
      if (deltafile)
         fclose(deltafile), deltafile=NULL;
#endif
   }

   // Do the opens--notice that all errors are fatal to this function
   char filename[MAX_LINE_LENGTH];

#ifdef MULTIPLE_INPUT
 for (int deltafilenum=0; deltafilenum<256; ++deltafilenum) {
#else
 int deltafilenum = 0;
#endif

   // Open the delta-encoded strings file
   if (snprintf(filename,MAX_LINE_LENGTH,deltamask,deltafilenum) >= 
                MAX_LINE_LENGTH) {
      if (verbose_errors)
         fprintf(stderr,"Error: Delta-encoded data filename too long.\n");
      retvalue = 0;
   } else if ((
#ifdef MULTIPLE_INPUT
               deltafile[deltafilenum]
#else
               deltafile
#endif
                                       = fopen(filename,"rt")) == NULL) {
      if (verbose_errors) {
         fprintf(stderr,"Error: Cannot open %s: ",filename);
         perror("");
      }
      retvalue = 0;
   }
#ifdef MULTIPLE_INPUT
 }  // for loop (deltafilenum: 0->255)
#endif

   // Open all the index files
   for (int i=0; i<256; ++i) {
      if (snprintf(filename,MAX_LINE_LENGTH,indexmask,i) >= MAX_LINE_LENGTH) {
         retvalue = 0;
         if (verbose_errors)
            fprintf(stderr,"Error: Filename for index files too long\n");
         continue; // flush all the errors (or break; to quit now)
      }
      if ((indexfile[i] = fopen(filename,"rb")) == NULL) {
         retvalue = 0;
         if (verbose_errors) {
            fprintf(stderr,"Error: Cannot open file %s: ",filename);
            perror("");
         }
         continue;
      }
      if (fseek(indexfile[i],0,SEEK_END) == -1) {
         retvalue = 0;
         if (verbose_errors) {
            fprintf(stderr,"Error: Cannot find end of file %s: ",filename);
            perror("");
         }
         continue;
      }
      if ((indexfilesize[i] = ftell(indexfile[i])) == -1) {
         retvalue = 0;
         if (verbose_errors) {
           fprintf(stderr,"Error: Cannot determine size of file %s: ",filename);
           perror("");
         }
         continue;
      }
      if (indexfilesize[i] % sizeof(struct index_record)) {
         retvalue = 0;
         if (verbose_errors)
            fprintf(stderr,"Error: Invalid filesize remainder %ld size %ld, file %s\n",(long int) (indexfilesize[i] % sizeof(struct index_record)), indexfilesize[i], filename);
         continue;
      }
      indexfilesize[i] /= sizeof(struct index_record);
   }
   if (retvalue == 0) {
      // abort!  abort!
      for (int i=0; i < 256; ++i)
         if (indexfile[i])
            fclose(indexfile[i]), indexfile[i]=NULL;
#ifdef MULTIPLE_INPUT
      for (int i=0; i < 256; ++i)
         if (deltafile[i])
            fclose(deltafile[i]), deltafile[i]=NULL;
#else
      if (deltafile)
         fclose(deltafile), deltafile=NULL;
#endif
   }

   return(retvalue);
} 


/* find_index_offset - does binary search to locate appropriate index entry
      returns 1 on success, 0 on failure; in either case, sets hashlookup_error
      value is the number to look up in (FILE*)indexfile[filenum]
      0 <= filenum <= 255 is the index file to search
      This function is recursive; set a range of offsets to search, such
      as 
         minoffset = 0   maxoffset = indexfilesize[filenum]
      if you know nothing about the location of value in indexfile[filenum].
      Notice the offsets are measured in index_records, not bytes.
      On success,
         *deltafilenum is set to 0 (always), if multiple delta-encoded
            file support is not implemented; else,
         *deltafilenum is set to the delta-encoded file number (0 to 255)
            to scan, if multile delta-encoded file support is enabled
         *offset is set to the offset in the delta-encoded file to start
            scanning for URLs hashing to value
      On failure, *deltafilenum and *offset are untouched.
*/
int find_index_offset(unsigned long long value,
      unsigned int *deltafilenum, unsigned long *offset,
      unsigned indexfilenum, unsigned long minoffset, unsigned long maxoffset)
{
   struct index_record record;
   unsigned long center;

//   cerr << "Debug: value=" << value << " filenum=" << indexfilenum
//        << " (" << minoffset << "," << maxoffset << ")" << endl;

   // function caller messed up?
   if (minoffset > maxoffset) {
      if (verbose_errors)
         fprintf(stderr,"Error: Internal error: minoffset %lu>maxoffset %lu\n",
            minoffset,maxoffset);
      hashlookup_error=INTERNAL;
      return 0;
   }
   if ((deltafilenum == NULL) || (offset == NULL)) {
      if (verbose_errors)
         fprintf(stderr,"Error: Internal error: pointer argument to find_index_offset is NULL\n");
      hashlookup_error=INTERNAL;
      return 0;
   }
   if (indexfile[indexfilenum] == NULL) {
      if (verbose_errors)
         fprintf(stderr,"Error: Internal error: program did not initialize_hashlookup() before using hashlookup()\n");
      hashlookup_error=INTERNAL;
      return 0;
   }

   // handle recursion's base case
   if (minoffset == maxoffset) {
      if (fseek(indexfile[indexfilenum], minoffset*sizeof(struct index_record),
         SEEK_SET)==-1) {
            if (verbose_errors)
               fprintf(stderr,"Error: Cannot seek to desired index entry\n");
            hashlookup_error = FILES;  return 0;
      }
      if (fread(&record, sizeof(record), 1, indexfile[indexfilenum]) != 1) {
         if (verbose_errors)
            fprintf(stderr,"Error: Cannot read desired index record\n");
         hashlookup_error = FILES;  return 0;
      }
      record.docID = Utils::ntohll(record.docID);
      record.filenum = Utils::ntohll(record.filenum);
      record.offset = Utils::ntohll(record.offset);
      if (record.docID != value) {
         hashlookup_error = NOHASH;  return 0;
      }
#ifdef MULTIPLE_INPUT
      *deltafilenum = record.filenum;
#else
      *deltafilenum = 1;
#endif
      *offset = record.offset;
      hashlookup_error = SUCCESS;
      return 1;
   }

   // recurse: split on the middle
   center = ((maxoffset - minoffset) / 2) + minoffset;
   if (fseek(indexfile[indexfilenum], center*sizeof(struct index_record), 
            SEEK_SET)==-1) {
      if (verbose_errors)
         fprintf(stderr,"Error: Cannot seek to intermediate index entry\n");
      hashlookup_error = FILES;  return 0;
   }
   if (fread(&record, sizeof(record), 1, indexfile[indexfilenum]) != 1) {
      if (verbose_errors)
         fprintf(stderr,"Error: Cannot read intermediate index record\n");
      hashlookup_error = FILES;  return 0;
   }
   record.docID = Utils::ntohll(record.docID);
   record.filenum = Utils::ntohll(record.filenum);
   record.offset = Utils::ntohll(record.offset);
//  cerr << "Debug: value at center " << center << ": " << record.docID << endl;
   if (record.docID == value) {
#ifdef MULTIPLE_INPUT
      *deltafilenum = record.filenum;
#else
      *deltafilenum = 1;
#endif
      *offset = record.offset;
      hashlookup_error = SUCCESS;
      return 1;
   } else if (record.docID > value) 
      return find_index_offset(value,deltafilenum,offset,indexfilenum,
                   minoffset,center);
   else // record.docID < value
   {
      if (center == minoffset)
         return find_index_offset(value,deltafilenum,offset,indexfilenum,
                      center+1,maxoffset);
      else
         return find_index_offset(value,deltafilenum,offset,indexfilenum,
                      center,maxoffset);
   }
   if (verbose_errors)
      fprintf(stderr,"Error: Internal error: Hey, how did find_index_offset fall through its recursive call?\n");
   hashlookup_error = INTERNAL;
   return 0;
}
 
/* hashlookup - looks up the string whose hash equals the given docID
   See the comments at the beginning of the file for more details on
   proper usage.

   This function calls find_index_offset to get the nearest "checkpoint"
   in the delta-compressed file from which to start scanning for possible
   matches to the desired string.  This checkpoint is an uncompressed line
   (its delta with prior lines is declared to be zero, no matter what),
   which allows hashlookup to delta-decompress subsequent lines to check their
   hashes for a match.  When hashlookup reaches a line whose hash matches
   the desired value, it returns the string.  In general, it assumes that
   it will eventually find the string because if the string is not present 
   in the delta-compressed list, then the string should not have had its hash 
   registered in the index files in the first place, and find_index_offset
   should have failed.

   This code has a minor sanity/insanity check, which makes the code fail if it
   takes too long (defined here as, more than DIE_LINE lines of the
   delta-compressed URL list have been scanned).  If this number is exceeded,
   hashlookup() fails with hashlookup_error = FILES, as if the delta-encoded
   URL list were corrupt.
*/

#define DIE_LINE 50000  // This is a long time, isn't it?

char *hashlookup(unsigned long long docID)
{
   unsigned int deltafilenum = 0, indexfilenum = (docID >> (64-8));
   unsigned long deltafileoffset;

   hashlookup_error = SUCCESS;
   if (find_index_offset(docID,&deltafilenum,&deltafileoffset,
             indexfilenum,0,indexfilesize[indexfilenum]))
   {
#ifdef MULTIPLE_INPUT
      FILE *deltafiletoread = deltafile[deltafilenum];
#else
      FILE *deltafiletoread = deltafile;
#endif
      unsigned int deltacount;
      char buffer[MAX_LINE_LENGTH];
      unsigned int bufferlen;

      DeltaDecode<CountType> decoder;
      char *space = NULL;

      unsigned int linecount = 0;

      // Scan the delta-compressed file for the URL
      // cerr << "Note: Check offset " << deltafileoffset << endl;
      if (fseek(deltafiletoread,deltafileoffset,SEEK_SET)==-1) {
         if (verbose_errors) 
            fprintf(stderr,"Error: Cannot seek to delta-compressed line.\n");
         hashlookup_error = FILES;
         return NULL;
      }

      if (fscanf(deltafiletoread,"%ud",&deltacount) != 1) {
         if (verbose_errors)
            fprintf(stderr,"Error: Cannot read delta-compression value.\n");
         hashlookup_error = FILES;  // we must start with a counting number
         return NULL;
      }
      if (fgetc(deltafiletoread) != ' ') {
         if (verbose_errors)
            fprintf(stderr,"Error: Lost synchronization in delta'd file.\n");
         hashlookup_error = FILES;  // synchronization in deltafile lost!
         return NULL;
      }
      if (fgets(buffer,MAX_LINE_LENGTH,deltafiletoread) == NULL) {
         if (verbose_errors)
            fprintf(stderr,"Error: Cannot read delta-compressed string.\n");
         hashlookup_error = FILES;
         return NULL;
      }
      bufferlen = strlen(buffer);
      if (buffer[bufferlen-1] == '\n')
         buffer[bufferlen-1] = '\0'; // overwrites \n
      else {
         if (verbose_errors)
            fprintf(stderr,"Error: Delta-compressed string exceeds MAX_LINE_LENGTH=%lu.\n",(unsigned long int) MAX_LINE_LENGTH);
         hashlookup_error = FILES;  // URL list line is invalidly long
         return NULL;
      }
      space = decoder.expand((CountType)deltacount,buffer);
      while (HASH(space) != docID) {
         delete [] space;  space = NULL;
         if (++linecount > DIE_LINE) {
            if (verbose_errors)
               fprintf(stderr,"Error: Unusually many (%ud+) lines searched (is delta'd file or index corrupt?\n", (unsigned int) DIE_LINE);
            hashlookup_error = FILES;  // we scanned too many lines
            break;  // keep as break, to connect to fprintf() in else{} below
         }

         if (fscanf(deltafiletoread,"%ud",&deltacount) != 1) {
            if (verbose_errors)
               fprintf(stderr,"Error: Cannot read delta-compression value.\n");
            hashlookup_error = FILES;  // we must start with a counting number
            break;  // breaks from here could also be return NULLs
         }
         if (fgetc(deltafiletoread) != ' ') {
            if (verbose_errors)
               fprintf(stderr,"Error: Lost synchronization in delta'd file.\n");
            hashlookup_error = FILES;  // synchronization in deltafile lost!
            break;
         }
         if (fgets(buffer,MAX_LINE_LENGTH,deltafiletoread) == NULL) {
            if (verbose_errors)
               fprintf(stderr,"Error: Cannot read delta-compressed string.\n");
            hashlookup_error = FILES;
            break; 
         }
         bufferlen = strlen(buffer);
         if (buffer[bufferlen-1] == '\n')
            buffer[bufferlen-1] = '\0'; // overwrites \n
         else {
            if (verbose_errors)
               fprintf(stderr,"Error: Delta-compressed string exceeds MAX_LINE_LENGTH=%lu.\n",(unsigned long int) MAX_LINE_LENGTH);
            hashlookup_error = FILES;  // URL list line is invalidly long
            break;
         }
         space = decoder.expand((CountType)deltacount,buffer);
      }
      if (space) {
         char *retvalue = strdup(space);
         delete [] space;
         return(retvalue);
      } else {
         if (verbose_errors) {
            fprintf(stderr,"Error: Internal error: hashlookup found checkpoint but no matching string\n");
            fprintf(stderr,"error: Software, index, or URL list may be corrupt.\n");
         }
         return NULL;
      }
   } else {
      // no offset found :(
      // find_index_offset already set hashlookup_error
      return NULL;
   }
   if (verbose_errors)
      fprintf(stderr,"Error: Internal error: hashlookup() fell through to unreachable point\n");
   hashlookup_error = INTERNAL;
   return NULL;
}


#ifdef MAIN

using std::cin;
using std::cout;
using std::cerr;
using std::endl;
using std::hex;

/* main - the filter program
   This code is designed to double as a filter implementation of hashlookup
   for shell scripts and pipes, and as an example of how to use the hashlookup 
   facility in other code.

   Notice that the user is trusted, in that a very poor filemask (that
   attempts to take more than one integer variable off the stack in sprintf)
   could crash initialize_hashlookup, a known vulnerability.

   This code returns
   0   all lookups completed successfully
   1   invalid number of arguments
   2   initialize_hashlookup (file opens) failed
   3   hashlookup failed for at least one hash
*/ 
int main(int argc, char *argv[])
{
   if ((argc < 3) || (argc > 4)) {
      cerr << "Fatal: Usage: " << argv[0] 
           << " indexfilemask deltafilemask [hex]"
           << endl;
      // Add the string 'hex' as shown to have hashlookup read hexadecimal
      return 1;
   }

   // Open all files
   verbose_errors = 1;
   if (!initialize_hashlookup(argv[1],argv[2]))
   {
      cerr << "Fatal: Cannot initialize_hashlookup()." << endl;
      return 2;
   }

   // Now handle the queries
   unsigned long long value;
   unsigned int retvalue = 0;
   if ((argc == 4) && (strcmp(argv[3],"hex")==0)) {
      cin >> hex;
   }
   cin >> value;
   while (!cin.fail()) {
      char *s = hashlookup(value);
      if (s == NULL) {
         cerr << "Error: hashlookup failed on error " << hashlookup_error
              << " looking up hash " << value << endl;
         retvalue = 3;
      }
      else {
         cout << s << endl;
         cout.flush();
      }
      cin >> value;
   }
   return(retvalue);
}

#endif /* #ifdef MAIN */
