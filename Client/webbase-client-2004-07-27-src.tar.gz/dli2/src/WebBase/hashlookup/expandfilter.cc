/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#include <iostream>
#include <string>
#include "undelta.h"

#include "normalize.h"

using std::cin;
using std::cout;
using std::cerr;
using std::endl;

// Filter-style main for testing and script integration

// Warning: This code is not robust, and is designed only for simple
// testing and direct use of the DeltaDecode class.

// It does happen to work in the current WebBase, however, because
// maketables promises its URL output will have strlen() < MAX_LINE_LENGTH

typedef unsigned short CountType;

#ifndef MAX_NUM_LENGTH
#define MAX_NUM_LENGTH (7)
#endif

int main(void)
{
   DeltaDecode<CountType> decoder;
   CountType compress;
   char buffer[MAX_LINE_LENGTH+MAX_NUM_LENGTH];
   char space;
   unsigned long l = 0;

   cin >> compress;
   cin.get(space);  // Absorb the space
   if (cin.fail() || (space != ' ')) {
      cerr << "Error: Improper format for delta-encoded data on first line"
           << endl;
      return 2;
   }
   cin.getline(buffer,MAX_LINE_LENGTH+MAX_NUM_LENGTH);
   while (1) {
      ++l;
//      cerr << "Debug: (" << compress << ',' << buffer << ')' << endl;
      char *result = decoder.expand(compress,buffer);
      cout << result << endl;
      delete [] result;
      cin >> compress;
      cin.get(space);
      if (cin.fail()) break;		// out of input
      if (space != ' ') 
         cerr << "Error: Lost sync with input stream on line " << l << endl;
      cin.getline(buffer,MAX_LINE_LENGTH+MAX_NUM_LENGTH);
   }
   cerr << "Note: " << l << " lines processed." << endl;
   return 0;
}
