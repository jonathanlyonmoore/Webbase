/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   undelta.cc - a simple delta-encoding-decompression class
   Wang Lam <wlam@cs.stanford.edu>
   February 1999
*/

#include <iostream>
#include <string>

using std::string;
using std::cerr;
using std::endl;

template <class CountingType>
DeltaDecode<CountingType>::DeltaDecode() : lastString(new char[1])
{
   *lastString = '\0';
}

template <class CountingType>
DeltaDecode<CountingType>::~DeltaDecode()
{
   delete [] lastString;
}

template <class CountingType>
char *DeltaDecode<CountingType>::expand(CountingType sublen, const char *s)
{
   if (s == NULL)
   {
      cerr << "Error: Internal error in DeltaDecode::expand caller" << endl;
      cerr << "error: s==NULL (but shouldn't) in DeltaDecode::expand [" 
           << __FILE__ << ':' << __LINE__ << ']' << endl;
      char *ret = new char[1];
      if (ret) { ret[0] = '\0'; }
      return ret;
   }
   if (sublen > strlen(lastString))
   {
      cerr << "Error: Internal error found at DeltaDecode::expand ["
           << __FILE__ << ':' << __LINE__ << ']' << endl;
      cerr << "error: attempting to merge more chars than available" << endl;
      cerr << "error: attempted to take " << (unsigned int) sublen
           << " chars from " << lastString << endl;
      sublen = 0;
   }
   
   int len = sublen + strlen(s) + 1;
   char *retvalue = NULL;
   do {
      retvalue = new char[len];
      if (retvalue == NULL) {
         cerr << "Error: Not enough memory for string of length "
              << sublen + strlen(s) << endl;
         --len;
      }
   } while (retvalue == NULL);

   strncpy(retvalue,lastString,sublen);
   strncpy(&retvalue[sublen],s,len-sublen-1 /* -1 to leave room for '\0' */);
   retvalue[len-1] = '\0';  // strncpy does not guarantee a '\0'

   char *newlast = new char [len];
   if (newlast == NULL) {
      cerr << "Error: Not enough memory to save delta-expanded string" << endl;
   } else {
      strcpy(newlast,retvalue);
      delete [] lastString;
      lastString = newlast;
   }
   
   return retvalue;
}
