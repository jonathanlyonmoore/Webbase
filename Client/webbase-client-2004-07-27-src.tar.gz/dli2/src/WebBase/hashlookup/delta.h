/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
   delta.h - a simple delta-encoding-compression class
   Wang Lam <wlam@cs.stanford.edu>
   February 1999

   Delta compression takes a stream of lines, sorted in some dictionary
   order, and compresses each line by omitting the longest prefix (substring)
   that it shares with the line prior in the stream.

   This class additionally supports occasional "checkpointing," in which
   a line is not compressed at all (its longest prefix is defined as zero)
   to provide an occasional reference line for later strings in the stream.
*/

#ifndef _DELTA_H
#define _DELTA_H

/* CountingType is the type that will be used to store the length of the
   substring each line shares with its previous.
   * Set CountingType to some type with assignment and integer addition.
   * If CountingType overflows (i.e., a string shares more characters with its
     prior string than CountingType can count), the code will automatically
     scale back compression to fit CountingType.
*/
template <class CountingType>
class DeltaEncode {
   public:
      // checkpointsize - number of lines between forced checkpoints,
      //                  or 0 if no forced checkpoints desired
      DeltaEncode(unsigned long checkpointsize = 0);
      ~DeltaEncode();

      // Set to true if you want messages to cerr when CountingType overflows
      bool reportDeltaOverflow;

      // This routine does the actual maximal-prefix search, without affecting
      // object state.  You probably don't need to call this directly.
      // Never send in NULL; empty strings are non-NULL pointers to '\0'.
      CountingType findDelta(const char *s1, const char *s2);

      // Takes a string and returns the number of characters to omit.
      // Never send in s==NULL; empty strings are non-NULL pointers to '\0'.
      CountingType delta(const char *s);

      // Determines how well this object is compressing so far.
      // 0 means no compression, 1 is equivalent to complete obliteration
      // negative values indicate the file expanded instead of contracted!
      inline float compressionRatio(void)
         { if (totalBytesOut)
              return 1.0 - ((float) totalBytesOut )/(float) totalBytesIn;
           else
              return 0;
         };
      
   protected:
      char *lastString;				// last string of stream
      unsigned long linesSinceCheckpoint;	// counts from last checkpt
      unsigned long linesBetweenCheckpoints;	// (see constructor)

      // Statistics gathering for compressionRatio()
      unsigned long long totalBytesIn;
      unsigned long long totalBytesOut;
};
      
#include "delta.cc"
#endif /* #ifdef _DELTA_H */


