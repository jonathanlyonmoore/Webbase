/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/* hash.cc - computes hashes of input strings (minus \n)
   Wang Lam <wlam@cs.stanford.edu>
   March 1999

   This is a simple filter front-end to the urlHash/urlHash.h:hash64()
   function.  Send in strings of up to 1024 characters (including \n),
   one per line, and watch the 64-bit hashes come out the other side as text.

   14 Jan 2000:
   Supply the command line argument "hex" (without quotation marks) to
   have the 64-bit hashes come out as hexadecimal instead of decimal numbers.
*/

#include <iostream>
#include <string>
#include "urlHash.h"

using std::cin;
using std::cout;
using std::hex;
using std::endl;

int main(int argc, char *argv[])
{
   char buffer[1025];
   int s;
   if ((argc > 1) && (strcmp(argv[1],"hex")==0)) {
      cout << hex;
   }
   do {
      cin.getline(buffer,1025);
      s = strlen(buffer);
      if (s && (buffer[s-1] == '\n')) buffer[s-1] = '\0';
      cout << hash64(buffer) << endl;
   } while (s && !cin.eof());
   return 0;
}
