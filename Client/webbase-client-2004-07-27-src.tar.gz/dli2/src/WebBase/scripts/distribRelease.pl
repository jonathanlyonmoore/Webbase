#!/usr/bin/perl -w
# client to release a distributor
# 
#   Gary Wesley <gary@db.stanford.edu> 4/02
use IO::Socket;
use Env;

unless (@ARGV == 1) { 
  print "usage: $0 port \n" ; 
exit(1); }

$port = $ARGV[0];

$EOL = "\015\012";

$host = "eh.stanford.edu";
$PORT= 7003; # change pingdd & distribdaemon too
 
$remote = IO::Socket::INET->new( Proto     => "tcp",
				 PeerAddr  => $host,
				 PeerPort  => $PORT ,
			       );
unless ($remote) { die "cannot connect to  daemon on $host" }
$remote->autoflush(1);

#actual call
print $remote "done,$port$EOL";
my $line = "";
read( $remote, $line, 100 );     # read reply (1st 100 chars) into $line
close $remote; 

print "distrib daemon returned: $line";
print "\n";
close $remote; 

exit;
