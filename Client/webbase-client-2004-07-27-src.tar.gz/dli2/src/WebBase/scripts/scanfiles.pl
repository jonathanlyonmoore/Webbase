#!/usr/bin/perl -w
# validate crawl by checking for files existence
# cat /u/testbed/dli2/doc/WebBase/crawl_lists/crawled_hosts.0204.f | scanfiles.pl /lfs/1/tmp/webbase/crawls/2004-02 image
#  
#   Gary Wesley <gary@db.stanford.edu> 11/3
require 5.003; # least we have tested on

my $EOL = "\015\012";

my $scanned = 0;

$dir = $ARGV[0];
$type = $ARGV[1];

open(STDERR, ">> errlog") || die $!;

# Find the path where the WebBase code tree begins.
use FindBin;
$_ = $FindBin::Bin;
s#/([^/]+)$#/# ; # happens to end in a slash
my $WEBBASE = "/u/gary/dli2/src/WebBase";

while( ($site,$fetched)  = split(/[\s\t]+/, <STDIN>) ){
    $scanned++;
    if(( $scanned % 500 ) == 0){ printf "scanned $scanned sites " . `date +%H:%M`; }
    #printf "$site $fetched| "; 

    if( ( $fetched == "" ) || $fetched > 1 ) {
	#build command
	($f1, $f2, $f3, $f4, $f5, $f6) = split(/\./, $site );
	#printf $f1, $f2, $f3, $f4, $f5, $f6 . "\n";
	$path = "$dir/$f6/$f5/$f4/$f3/$f2/$f1/_repository_/$type/repository.0";
	#printf $path . "\n";
	#$cmd = "ls $path";
	printf $cmd . "\n";
	`ls $path`;
	#printf $exit_value;
	my $exit_value = $? >> 8;
	    if($exit_value > 0){ 		
		printf STDOUT  ">>>>>>Bad: $site ";
	    }
    }
    #else{ print "0,1 site";}
}
exit 0;
