/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * bin2text.cc
 * Converts a binary input stream of numbers to an ASCII output stream of
 * numbers
 *
 * Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Utils.h"

int main() {
  unsigned long long a, b;

  if(sizeof(a) != 8) {
    std::cerr << "No long long support...exiting" << std::endl;
    exit(1);
  }

  std::cout.fill('0');

  while(true) {
    cin.read((char*) &a, sizeof(a));
    //    a = Utils::ntohll(a);
    if(cin.eof()) break;
    cin.read((char*) &b, sizeof(b));
    //    b = Utils::ntohll(b);
  
    if(cin.fail()) {
      std::cerr << "input bad" << std::endl;
      exit(1);
    }

    std::cout << std::setw(20) << a << '\t' << std::setw(20) << b << std::endl;
  }
}


