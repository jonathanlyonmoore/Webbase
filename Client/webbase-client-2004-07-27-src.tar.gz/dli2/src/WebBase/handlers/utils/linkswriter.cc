/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*                         WebBase project
 *                         ---------------
 *                     
 * Interface for writing links output by webcat to a file
 *
 * Author: Taher H. Haveliwala - taherh@cs.stanford.edu
 */

#include <iostream>
#include <fstream>
#include <vector>
#include <assert.h>

#include <iomanip>

#include "linkswriter.h"
#include "Utils.h"

#define ASSERT assert

LinksWriter::LinksWriter(const char* linksdir, const char* baseFilename,
			 bool append0) {
  append = append0;
  if(!createFileTable(linksdir, baseFilename)) {
    std::cerr << "Exiting..." << std::endl;
    exit(1);
  }
}

bool
LinksWriter::createFileTable(const char* linksdir, const char* baseFilename) {
  // now open the corresponding files
  // buf is 2*MAX_LINE+2 so it can hold
  //             directory, optional /, filebase, and 2 digit suffix
  int i;
  for(i = 0; i < 256; i++) {
    char buf[2*MAX_LINE+2];

    std::ostringstream fname(buf,  std::_Ios_Openmode(2*MAX_LINE+2 ));
    fname << linksdir;
    if(linksdir[strlen(linksdir)-1] != '/') {
      fname << '/';
    }
    fname << baseFilename << "." << std::setfill('0') << std::setw(3) << i <<std:: ends;
    if (append) {
      std::cerr << "Appending to file: " << buf << std::endl;
      files[i].open(buf, ios::app);
    }
    else {
      std::cerr << "Opening file: " << buf << std::endl;
      files[i].open(buf);
    }

    if(!files[i].is_open()) {
      std::cerr << "Could not open file: " << buf << std::endl;
      return false;
    }
  }
  return true;
}

bool
LinksWriter::writeLink(unsigned long long sourceId, 
		       std::vector<unsigned long long int>& destIds) {
  std::ostream& file = getFileFor(sourceId);
  
  //  unsigned long long sourceId = Utils::htonll(sourceId);
  file.write((char*) &sourceId, sizeof(sourceId));
  
  unsigned long long size = destIds.size();
  // FIXME
  file.write((char*) &size, sizeof(size));

  unsigned long long dest;
  std::vector<unsigned long long int>::iterator iter;

    for(iter = destIds.begin(); iter != destIds.end(); iter++) {
      dest = *iter;
      file.write((char*) &dest, sizeof(dest));
    }

    if(file.fail()) {
      std::cerr << "Couldn't write link" <<std:: endl;
      return false;
    }
    return true;
}

ofstream&
LinksWriter::getFileFor(unsigned long long id) {
  int whichFile = id >> 56;
  ASSERT(whichFile < 256 && whichFile >= 0);
  return  files[whichFile];
}

