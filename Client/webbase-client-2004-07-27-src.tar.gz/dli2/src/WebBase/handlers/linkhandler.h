/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Simple hyperlink handler interface
 * Based on the simple (document) handler interface by Taher Haveliwala
 *
 * Wang Lam <wlam@cs.stanford.edu> 27 Feb 2001
 */

#ifndef _LINKHANDLER_H_
#define _LINKHANDLER_H_

#include <string>

/* Call sequence for hyperlink handlers:
 * constructor Init (NewSource NewDestination* EndSource)* Finish destructor
 *
 * HasFatalError and RequestsDisconnect may be called between any two calls
 * above.  If HasFatalError() is true, LinkParser will try to terminate
 * the entire process.  If RequestsDisconnect is true, LinkParser will 
 * call Finish, then destruct the LinkHandler; the LinkHandler will receive
 * no more hyperlinks (even if in the middle of a source).
 */
class LinkHandler {
   public:
      // virtual bool Init() { return true; } ;
      virtual void Init() {};
      virtual void NewSource(string url, string time, int docid,
         unsigned long long reppos) {};
      virtual void NewDestination(string url) {};
      virtual void EndSource() {};
      virtual void Finish() {};
      virtual ~LinkHandler() {};

      virtual bool HasFatalError() { return false; };
      virtual bool RequestsDisconnect() { return false; };
};

#endif // _LINKHANDLER_H_

