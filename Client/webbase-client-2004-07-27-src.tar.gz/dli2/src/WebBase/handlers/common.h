/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Some common typedefs/defines
 */

#ifndef __COMMON_H__
#define __COMMON_H__

#include <map>
typedef unsigned long long uint64;
typedef unsigned long uint32;

using std::map;

/*
// gcc doesn't have a default hash for ull 
class ULLHash {
  hash<uint32> hasher;
 public:
  uint64 operator()(const uint64& x) const {
    uint64 val = x;
    return hasher((uint32)val) + hasher((uint32) (val >> 32));
  }
};
*/

inline uint64 loseSlash(uint64 hash) { 
  return (hash & 0xFFFFFFFFFFFFFFFEULL);
}

#ifndef DELIMITER
#define DELIMITER "==P=>>>>=i===<<<<=T===>=A===<=!Junghoo!==>"
#endif

#endif // __COMMON_H__
