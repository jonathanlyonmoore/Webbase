/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Generates bucketed list of all referenced URLs in WebBase
 *
 * Wang Lam <wlam@cs.stanford.edu> 28 Feb 2001
 */

#ifndef _URLLIST_H_
#define _URLLIST_H_

#include "linkhandler.h"

#include <cstdlib>
#include <iostream>
#include <string>
#include <cstring>
#include "confTable.h"
#include "urlwriter.h"
#include "url2hash.h"

class URLList : public LinkHandler {
   public:
      URLList() : urlWriter(NULL), fatal(false), wantOut(false) {} ;

      void Init() {
         
         // Find out where to write the URL list.
         const char *urlsDir = conf.getValue("URLS_DIR");
         const char *bp      = conf.getValue("BRKPT_FILE");
         const char *strSrcOnly = conf.getValue("SRC_ONLY");
         srcOnly = false;
         if(std::string("1") == strSrcOnly) {
           srcOnly = true;
         }
         if (!urlsDir || !bp) {
            std::cerr << "*** class UrlList::Init "
		      << __FILE__ << ':' << __LINE__
                      << ": No value for URLS_DIR and/or BRKPT_FILE."
		      << std::endl;
            fatal = true;
            return;
         }

         // Instantiate Sriram's URLWriter code.
         urlWriter = new UrlWriter(urlsDir, "urlsFile", bp);
         if (urlWriter == NULL) {
	    std::cerr << "*** class UrlList::Init "
		      << __FILE__ << ':' << __LINE__
                      << ": Out of memory: cannot construct UrlWriter."
		      << std::endl;
            fatal = true;
            return;
         }
      };

      void NewSource(std::string url, std::string time, int docid,
         unsigned long long reppos) {
         WriteURL(url);
      };
      void NewDestination(std::string url) {
	 if(!srcOnly) WriteURL(url);
      };
      void EndSource() {};

      void Finish() { delete urlWriter; };

      bool HasFatalError() { return fatal; };
      bool RequestsDisconnect() { return wantOut; };

   private:
      UrlWriter *urlWriter;
      ConfLoader confLoader;
      bool fatal;
      bool wantOut;
      bool srcOnly;

      void WriteURL(std::string url) {
         if (urlWriter == NULL) {
	    std::cerr << "*** class UrlList::Write "
		      << __FILE__ << ':' << __LINE__
                      << ": Internal error: urlWriter was not instantiated." 
                      << std::endl;
            wantOut = true;
            return;
         }

         char *normurl = strdup(url.c_str());
         if (normurl == NULL) {
	    std::cerr << "*** class UrlList::Write "
		      << __FILE__ << ':' << __LINE__
                      << ": Out of memory: cannot strdup " << url
		      << ", skipped." << std::endl;
         } else {
            normalize(normurl);
            unsigned long long hash = url2hash(normurl);
            urlWriter->writeUrl(normurl,hash);
         }
	 std::free(normurl);
      }
};

#endif // _URLLIST_H_

