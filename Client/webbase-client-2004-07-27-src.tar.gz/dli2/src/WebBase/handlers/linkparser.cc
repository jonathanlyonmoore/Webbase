/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Link parser absorbs Web pages and invokes link handlers on its hyperlinks
 * Wang Lam <wlam@cs.stanford.edu> 28 Feb 2001
 *
 */

#include <string>
#include "linkparser.h"
#include "linkhandler.h"
#include "html_parser.h"
// #include "url.h"
// libwww replacement:
#ifndef HAVE_CONFIG_H
#define HAVE_CONFIG_H
#endif
#include <WWWCore.h>
#include <HTParse.h>

// Create a new NUL('\0')-terminated string using the sequence of 
// characters between begin and end, including *begin but excluding *end.
// Returns a malloc'd buffer holding the string, which caller must free(), 
// or NULL if malloc returns NULL.
//
char *makeString(const char *begin, const char *end)
{
   if (end < begin) {
      // cerr << __FILE__ << ':' << __LINE__ 
      //     << ":makeString called incorrectly" << endl;
      return NULL;
   }

   size_t chars = end - begin + 1;  // 1 for NUL character
   // cerr << "makeString: ";
   // for (int i = 0; i < chars-1; ++i)
   //    cerr << begin[i];
   // cerr << endl;
   char *retvalue = (char *) malloc(chars);
   if (retvalue == NULL) return NULL;

   strncpy(retvalue,begin,chars - 1);
   retvalue[chars - 1] = '\0';
   return(retvalue);
}

void LinkParser::Init(void)
{
   return;
}

void LinkParser::Process(const string& page, string url, string time, int docid,
                       unsigned long long reppos)
{
   // Notify LinkHandlers of new page.
   std::vector<LinkHandler*>::iterator i;
   for (i = linkHandlers.begin(); i != linkHandlers.end(); ++i)
      (*i)->NewSource(url,time,docid,reppos);

   // We need a char* buffer for the page, for Junghoo's HTML parser code.
   const char *start = page.c_str();
   const char *end = start + page.length();

   // Do what webcat did--adapting C++ STL strings to C's const char *.
   // Parsing URLs relative to the relevant base URL is now done with libwww,
   // rather than with Junghooo's custom class static_url.
   // As a side effect, we no longer have a URL length limit, 
   // and push the job of discarding long URLs to individual handlers.

   int         tag;
   const char  *url_start, *url_end;
   // Move to libwww:
   // static_url  base, link;
   string base;

   // base.replace(url.c_str(), url.c_str() + url.length());
   base = url;
   parser.start_parse(start, end);
   while ((tag = parser.get_link(url_start, url_end)) >= 0) {
      char *urlbuffer = makeString(url_start,url_end);
      if (tag == html_parser::BASE) {
         // static_url temp(base);
         // base.replace(url_start, url_end, temp);
         char *newbase = HTParse(urlbuffer,base.c_str(),PARSE_ALL);
         newbase = HTSimplify(&newbase);
         base = newbase;
         free(newbase);
      } else {
         // link.replace(url_start, url_end, base);
         char *link = HTParse(urlbuffer,base.c_str(),PARSE_ALL);
         link = HTSimplify(&link);
         if (tag == html_parser::AREA || tag == html_parser::A ||
             tag == html_parser::LINK || tag == html_parser::FRAME ||
             tag == html_parser::IFRAME) {
            // link.strcpy(url_buffer, url_buffer + URL_BUFFER_SIZE);

            // Notify LinkHandlers of new hyperlink destination.
            // string desturl = url_buffer;
            string desturl = link;
            for (i = linkHandlers.begin(); i != linkHandlers.end(); ++i)
               (*i)->NewDestination(desturl);

         }
         free(link);
      }
      free(urlbuffer);
   }
   parser.end_parse();

   // Notify LinkHandlers of the end of the page.
   for (i = linkHandlers.begin(); i != linkHandlers.end(); ++i)
      (*i)->EndSource();
} 

void LinkParser::Finish()
{
   std::vector<LinkHandler*>::iterator i;
   for (i = linkHandlers.begin(); i != linkHandlers.end(); ++i)
      (*i)->Finish();

   return;
}

