/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 2003 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 *  Handler for splitting up a stream into 1 file per page
 *
 * Author: Gary Wesley <gary@db.stanford.edu> 10/03
 * Version: 1
 */
#include "splitup-cat-handler.h"


void SplitCat::Process(const string& html, string url, string time, 
	     int docid, unsigned long long offset)
{
  std::string::size_type slash = 0;
  std::string partialDir;
  std::string systemCallStr ;
  std::string dir = url.substr(7); // get rid of http://
  std::string::size_type tilde = 0;
  int rc = 0;

  do {    
    // replace chars that Linux doesn't like in filenames
    tilde = dir.find('~', tilde + 1);
    if( tilde  < dir.size() ){ 
      //cerr << ">SplitCat: replace ~ "  << endl; 
      dir.replace( tilde , 7 , "[tilde]");
    }

    slash = dir.find('/',slash+1);
    if ( slash < dir.size() ){
      if (slash == std::string::npos) slash = dir.size();
      partialDir.assign(dir,0,slash);
      //cerr << "SplitCat: checking path " << partialDir << endl;
      struct stat buf;

      if (stat(partialDir.c_str(),&buf) == -1) {
	if (mkdir(partialDir.c_str(),0777) != 0) {   // Let umask sort out permissions
	  cerr << "SplitCat: cannot create directory " << partialDir << '!' << endl;
	  return;
	}
      } else {
	if (!(buf.st_mode & S_IFDIR)) {
	  
	  //cerr << ">>SplitCat: " << partialDir << " must be, but is not,"
	  //     <<     "a directory!  Cannot open container for site " << dir << endl;   
	  systemCallStr =  "rm " + partialDir;
	  //cerr << "fixit: " << systemCallStr << endl << endl;
	  rc = system (systemCallStr.c_str());
	  if( rc != 0 ) {
	    cerr << "system (systemCallStr.c_str()); failed " << rc << endl; 
	    return ;
	  }
	  if (mkdir(partialDir.c_str(),0777) != 0) {   // Let umask sort out permissions
	    cerr << "SplitCat: cannot create directory " << partialDir << '!' << endl;
	    return;
	  }
	  else {
	    stat(partialDir.c_str(),&buf);
	    
	    if (!(buf.st_mode & S_IFDIR)) {
	      
	      cerr << "SplitCat: " << partialDir << " must be, but is not,"
		   <<     "a directory!  Cannot open container for site again: " << dir << endl; 
	      return;
	    }
	  }
	}
      }
    }
  } while (slash < dir.size());  

  //  int fd = creat(  dir.c_str(), 0644 );
  //ofstream outfile( fd );
  ofstream outfile(  dir.c_str() );
if(! outfile ){
    cerr << "SplitCat: Could not open: " << dir << endl;
    return;
  }
  outfile << "URL: " << url << endl;
  //outfile << "Date: " << time << endl;
  
  //outfile << endl;
  outfile << html << endl;
  outfile.close();
  //if( outfile )
  //cerr << "SplitCat: Created file: " << dir << endl;
}
