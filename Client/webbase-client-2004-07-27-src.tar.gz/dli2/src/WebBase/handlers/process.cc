/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/* 
 * Driver loop for invoking various handlers (extract-anchor, extract-body)
 * using various feeders (Network, WebCat, File) for input
 * 
 * If you prefer using a next() strategy, rather than a handler strategy,
 * don't use this.  Instantiate the appropriate feeder using FeederFactory,
 * and use it directly.
 * 
 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream>
#include <string>

// The handlers
#include "all_handlers.h"

// The feeders
#include "FeederFactory.h"

vector<Handler*> handlers;

void Usage() {
    cerr << "Usage: "
	 << "RunHandlers webbase.conf <net://hostname:portno/?queryString | file://dummy-host/file?queryString | rep://dummy-host/repfile?queryString>  [restrict]" 
	 << endl;
    exit(1);
}

int main(int argc, char *argv[])
{ 
  if(argc != 3 && argc != 4) {
    Usage();
  }

  // Load config values using the ConfLoader  
  conf.init( argv[1] );

  string source = argv[2];

  // figure out if a file/cin will tell us to seek from page to page
  string restrict_filename;
  std::istream* restrict_file = NULL;
  if(argc == 4) {
    restrict_filename = argv[3];
    if(restrict_filename == "-") {
      restrict_file = &cin;
      cerr << "Reading in offsets from standard in" << endl;
    }
    else {
      restrict_file = new std::ifstream(restrict_filename.c_str());
      if(restrict_file->fail()) {
	cerr << "Couldn't open " << restrict_filename << endl;
	exit(1);
      }
    }
  }

  InitHandlers();

  Feeder* feeder;
  
  feeder = FeederFactory::create_feeder(source); // , numpages);
  if(feeder == NULL) {
    Usage();
  }

  int cnt = 0;
  unsigned long long offset;
  while(true) {
    // seek if needed
    if(restrict_file != NULL) {
      (*restrict_file) >> offset;
      if(restrict_file->eof() || restrict_file->fail()) break;
      feeder->seek(offset);
    }
    // invoke iterator
    if(!feeder->next()) break;

    const char* data = feeder->getData();
    int size = feeder->getDataSize();
    //    cout << "size: " << size << " data: " << data <<  endl;
    string page(data, size);
    InvokeHandlers(page, feeder->getURL(), "", 
		   feeder->getDocId(), feeder->getOffset());
    if(++cnt % 10000 == 0) cerr << "Processed " << cnt << " pages." << endl;
  }

  FinishHandlers();
}
