/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 *  Handler(s) for pageLengths index
 *
 *  ( an example invocation for process:
 *    process rep:///u/gary/dli2/src/WebBase/inputs/rep2001 <numpages> (file is on Eh)
 *     or    file://example-50-pages <numpages>
 *     or     net://eh:9191 <numpages>  (after you have gotten a distributor socket)
 *  )
 *
 * Definition of a page length used:
 * robot.txt or 404 not found gives 0 length
 * else 
 *   ver 1) use bytes after header
 *   ver 2) count bytes stripped of HTML,
 *           unless = MAX, whereas we do not strip

 * Author: Gary Wesley <gary@db.stanford.edu> 4/01
 * Version: 2.1
 */

#include "pagelength-handler.h"
//#include "webbase.h"  // global webbase defs


PageLength::PageLength( ){  
    recoverable_error   = false;
    unrecoverable_error = false;
    
    
    pageLengthDir = conf.getValue("SIZES_SCRATCH");  // new in 2.1
    if (! pageLengthDir) {
      cerr << "Value of parameter SIZES_SCRATCH not available" << endl;
      recoverable_error = true;
      return;
    }    
    pagelengthWriter = new PagelengthWriter( pageLengthDir, "pagesizesFile" );
#ifdef noHTML   
    cout << "Sans-HTML length calculation used (HTML uncounted)" << endl;
#else
    cout << "Full length calculation used (ALL bytes)" << endl;
#endif
}


PageLength::~PageLength(){  if(debug) cout << " PageLength::~PageLength()" << endl;  }

void  PageLength::Init() { 
  if(debug) cout << " PageLength::Init() "  << endl; 
  debug = 0;
}

void  PageLength::Finish() { 
  if(debug) cout << "PageLength::finish" << endl;
  delete pagelengthWriter;
}

/* See if the URL ends with /robots.txt
 */
inline bool  PageLength::robotText( string& url ){
  //if(debug) cout << "robot:" << url.length() << " " << strlen( "robots.txt") << " "  << ( url.length()- strlen( "robots.txt") ) << " " <<  url.rfind( "robots.txt", url.length()- strlen( "robots.txt") ) <<  endl;
  return url.rfind( "robots.txt", url.length()- strlen( "robots.txt") ) <= url.length();
}


//
// Do the actual work
//

void  PageLength::Process(const string& html, string url, string time, 
	        	      int docid, unsigned long long offset) {
 
  if(debug) cout <<  "Process pageLength start: " << url << endl; 
  
  int htmlLength = html.length(); // small optimization
  int bodyLength = 0; 
  //if(debug) cout <<  robotText(url)  << " find:" <<  html.find( " 404 Not Found") << " notfind= " << (! ( html.find( " 404 Not Found") )) << endl;
  if(! robotText(url) && ! ( html.find( " 404 Not Found", 40, 600) < htmlLength)) { // avoid missing or disabled pages
    
    if(htmlLength > CRAWL_MAX_BYTES ) 
      cout << "Long: " << url << "\t" << htmlLength << " bytes" << endl;
    if(debug) cout << "From:   '" << html << "'\t" << htmlLength << " bytes" << endl;
    
#ifdef noHTML  
    if(htmlLength >= ( CRAWL_MAX_BYTES - 1 ) ) // so it was very likely truncated by crawler
         bodyLength = htmlLength;
    else bodyLength = HTML2Plain::countnon( html.c_str() );
#else
    if( htmlLength > typicalHeaderLength)
         bodyLength = htmlLength - typicalHeaderLength;
    else bodyLength = htmlLength;
#endif
    
  }
  if(debug) cout << url2hash(url) << " from " <<  url << '\t' << bodyLength << endl; 
  pagelengthWriter->writePagelength(  bodyLength,  url2hash(url) );
}
