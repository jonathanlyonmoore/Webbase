/*
 * CatHandler.java
 *
 */

package webbase.handlers;

import java.util.Properties;

import webbase.Constants;

/**
 * Simply outputs the page to stdout
 *
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public class CatHandler implements Handler {
    /**
     * outputs the page to stdout
     */
    public void processPage(byte[] data, String URL, long offset,
			    String timestamp, Properties properties) {
	System.out.println("URL: " + URL);
	System.out.println("Date: " + timestamp);
	System.out.println("Offset: " + offset);
	System.out.println();
	System.out.println(new String(data));
	System.out.println(DELIMITER);
    }
}


