/*
 * Handler.java
 *
 * Handler interface
 *
 * Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
 *
 */

package webbase.handlers;

import java.util.Properties;

import webbase.Constants;

/**
 * Abstract interface for document handlers.  A handler provides access to
 * a set of web pages using a push-style (callback) iterative interface.
 *
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public interface Handler extends Constants {
    /**
     * A handler should implement the following callback
     */
    public void processPage(byte[] data, String URL, long offset,
			    String timestamp, Properties properties);
}
