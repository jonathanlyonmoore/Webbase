/*
 * DMOZFeeder.java
 *
 * Provides access to some locally stored pages listed in the Open Directory
 *
 * Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
 *
 */

package webbase.feeders;

import java.io.*;
import java.util.*;

/**
 * DMOZFeeder provides access to pages from three top level 
 * categories of the open directory.  Each page is adorned with the
 * "Category" property, which says where the page was taken from in
 * the OpenDirectory hierarchy.
 *
 * @author Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
public class DMOZFeeder implements Feeder {
    private RandomAccessFile m_file;
    private Properties m_properties = new Properties();
    private String m_data = "";

    /**
     * initialize this feeder with fully qualified filename
     * possible input files are in /afs/ir/class/cs276a/data1/dmoz/
     */
    public DMOZFeeder(String filename) {
	try {
	    m_file = new RandomAccessFile(filename, "r");
	    String line = m_file.readLine();
	    if(! line.equals(DELIMITER)) {
		throw new
		    IOException("Invalid File");
	    }
	} catch(IOException e) {
	    System.err.println(e.getMessage());
	    System.exit(1);
	}
    }

    /**
     * goto pos
     */
    public boolean seek(long pos) {
	try {
	    m_file.seek(pos);
	    // Special case for beginning of file
	    if(pos == 0) {
		String line = m_file.readLine();
		if(! line.equals(DELIMITER)) {
		    throw new
			IOException("Invalid File");
		}
	    }
	    return true;
	} catch(IOException e) {
	    System.err.println(e.getMessage());
	    return false;
	}
    }

    /**
     * scan ahead to the next delimiter
     * used internally
     */
    private boolean resync() {
	try {
	    String line;
	    // Read in page (including http headers)
	    while( true ) {
		line = m_file.readLine();
		if(line == null) return false;
		if(line.equals(DELIMITER)) return true;
	    }
	} catch(IOException e) {
	    System.err.println(e.getMessage());
	    return false;
	}
    }

    /**
     * move to the next record
     */
    public boolean next() {
	try {
	    m_properties.clear();
	    m_properties.setProperty("Offset", 
				     String.valueOf(m_file.getFilePointer()));

	    String line = "";
	    // Read in WebBase header
	    while( (line = m_file.readLine()) != null && !line.equals("")) {
		int i = line.indexOf(":");
		// resync on a bad header
		if(i < 0) {
		    System.err.println("Bad header.  Resyncing...");
		    resync();
		    m_properties.clear();
		    m_properties.setProperty("Offset", 
					     String.valueOf(m_file.getFilePointer()));
		    continue;
		}
		String propName = line.substring(0, i);
		String propValue = line.substring(i+2);
		m_properties.setProperty(propName, propValue);
	    }
	    // we reached EOF
	    if(line == null) {
		return false;
	    }

	    StringBuffer page = new StringBuffer();
	    // Read in page (including http headers)
	    while( !(line = m_file.readLine()).equals(DELIMITER)) {
		page.append(line + "\n");
	    }
	    
	    m_data = page.toString();
	} catch(IOException e) {
	    System.err.println(e.getMessage());
	    return false;
	}
	return true;
    }

    /**
     * get the current page as a byte array
     */
    public byte[] getData() {
	return m_data.getBytes();
    }

    /**
     * get the current page as a string
     */
    public String getDataString() {
	return m_data;
    }

    /**
     * just return getDataString, since DMOZ data doesn't have HTTP headers
     */
    public String getPageString() {
	return getDataString();
    }

    /**
     * get the URL of the current page
     */
    public String getURL() { 
	return getProperty("URL");
    }

    /**
     * get the offset of the current page
     */
    public long getOffset() { 
	//	return Long.parseLong(getProperty("Position"));
	return Long.parseLong(getProperty("Offset"));
    }
    
    /**
     * get the timestamp of the current page
     */
    public String getTimestamp() { 
	return getProperty("Date");
    }

    /**
     * get the value of auxiliary properties
     * "Category" is a useful property
     */
    public String getProperty(String key) {
	return m_properties.getProperty(key);
    }

    /**
     * get all the properties
     */
    public Properties getAllProperties() {
	return m_properties;
    }

    public static void main(String[] args) {
	if(args.length != 1) {
	    System.err.println("Usage: java webbase.feeders.DMOZFeeder input_file");
	    System.err.println("Hint: possible input files are in /afs/ir/class/cs276a/data1/dmoz/");
	    System.exit(1);
	}
	
        DMOZFeeder r = new DMOZFeeder(args[0]);
	if(!r.seek(0)) {
	    System.err.println("Couldn't seek to beginning of file");
	    System.exit(1);
	}
	while(r.next()) {
	    System.out.println("URL: " + r.getURL());
	    System.out.println("Date: " + r.getTimestamp());
	    System.out.println("Offset: " + r.getOffset());
	    System.out.println();
	    System.out.println(r.getPageString());
	    System.out.println(DELIMITER);
	}
    }
}
