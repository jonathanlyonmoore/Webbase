/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/******************************************************************************
 *                          SiteEnumerator
 * 
 * Author : Sriram Raghavan <rsram@cs.stanford.edu>
 *****************************************************************************/

#include "SiteEnumerator.h"
#include <fstream>
#include <sstream>

SiteEnumerator::SiteEnumerator(std::string sf, std::string first, std::string last)
    : sitesFile(sf), firstSite(first), lastSite(last)
{

  // Try to open sites file
  sitesFileStream.open(sitesFile.c_str());
  if (! sitesFileStream.is_open()) {
    cerr << "SiteEnumerator: Unable to open sites file '" << sitesFile << "'" << endl;
    moreSites = false;
    return;
  }

  // if firstSite is specified, search sites-file for that site
  nextSite = "";
  moreSites = true;
  while (! sitesFileStream.eof()) {
    getline(sitesFileStream, nextSite);
    if (firstSite.length() == 0 && nextSite.length() > 0) break;
    if (firstSite.length() > 0 && nextSite == firstSite) break;
    nextSite = "";
  }
  if (nextSite == "") moreSites = false;
}

std::string SiteEnumerator::getNextSite()
{
  if (! moreSites) return "";

  moreSites = false;
  std::string siteToReturn = nextSite;

  if (nextSite != lastSite) {
    nextSite = "";
    while (! sitesFileStream.eof()) {
      getline(sitesFileStream, nextSite);
      if (nextSite.length() > 0) break;
    }
    if (nextSite.length() > 0) moreSites = true;
  }

  return siteToReturn;
}


// int main(int argc, char *argv[])
// {
//   if (argc != 4) {
//     cerr << "Usage: " << argv[0] << " <sitesFile> <firstSite> <lastSite>" << endl;
//     return -1;
//   } 

//   SiteEnumerator se(argv[1], argv[2], argv[3]);
//   while (se.hasMoreSites())
//     cout << se.getNextSite() << endl;
//   return 1;
// }
