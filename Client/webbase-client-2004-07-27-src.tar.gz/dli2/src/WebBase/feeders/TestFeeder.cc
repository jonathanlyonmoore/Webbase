/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*********************************************************************************
 *                          Test Feeder Client
 * 
 * A test feeder client that prints all the received information to stdout.
 * Also prints statistics on data sizes and incoming data rates - useful
 * to test the network feeder.
 * 
 * Author : Sriram Raghavan <rsram@cs.stanford.edu>
 *********************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "Feeder.h"
#include "FeederFactory.h"
#include "Utils.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <zlib.h>
#include <getopt.h>
#include <string>

int main(int argc, char *argv[])
{
  extern char *optarg;
  extern int optind;
  int option_char;
  string usageInfo = " -u <feeder uri> [-p -n <page skip frequency>]\n\t -p turns on page printing, disabled by default\n";

  // Initialize parameters
  bool pagePrint = false;
  int skipFrequency = 100;
  string feederURI = "";

  // Modify parameters based on commandline arguments
  while ((option_char = getopt(argc, argv, "u:pn:")) != EOF) {
    switch (option_char) {
      case 'u': feederURI.assign(optarg); break;
      case 'p': pagePrint = true; break;
      case 'n': sscanf(optarg, "%d", &skipFrequency); break;
      case '?': cout << "Usage: " << argv[0] << usageInfo; return(-1);
    }
  }

  if (feederURI.empty()) {
    cout << "Usage: " << argv[0] << usageInfo; 
    return(-1);
  }

  // If unable to instantiate feeder, exit with message
  Feeder *f = FeederFactory::create_feeder(feederURI);
  if (f == NULL) {
    cout << "Unable to instantiate feeder " << feederURI << endl;
    return(-1);
  }
  
  // Setup measurement variables and buffers
  long long totalSize = 0, totalUncompressed = 0;
  int count = 0;
  char* uncompressionBuffer = (char*) malloc(MAX_FILE_SIZE);
  const char * page;
  
  // Timing variables
  long long T0 = Utils::currentTimeMillis();
  long long duration;

  cout << "TestFeeder: Receiving document type = " << (int)(f->getDocType()) << endl;

  // Repeatedly call next on the feeder
  while (f->next()) {

    page = f->getData();

    // Uncompress if needed
    if ((f->getDocType() & COMPRESSED_TYPE) != 0) {
      uLongf uncompressedSize = MAX_FILE_SIZE;
      int status = uncompress((Bytef*)uncompressionBuffer, &uncompressedSize, (Bytef*)page, f->getDataSize());
      if (status != Z_OK) {
        cerr << "Error uncompressing page with docID " << f->getDocId() << endl;
        continue;
      }
      totalUncompressed += uncompressedSize;
      page = uncompressionBuffer;
      *(char *)(page + uncompressedSize) = '\0';
    }

    totalSize += f->getDataSize();

    // Print statistics every nth page
    if (count++ % skipFrequency == 0) {
      duration = Utils::currentTimeMillis() - T0;
      cout << "DocID: " << f->getDocId() << endl;
      cout << "Offset: " << f->getOffset() << endl;
      cout << "Timestamp: " << f->getTimestamp() << endl;
      cout << "Pagesize: " << f->getDataSize() << endl;
      cout << "URL: " << f->getURL() << endl;
      cout << "Total size: " << (totalSize / 1024) << " K (uncompressed " << (totalUncompressed/1024) 
           << " K)" << endl;
      if (duration != 0) {
        cout << "KB/s: " << (totalSize * 1000 / 1024) / duration << " (uncompressed " 
             << (totalUncompressed * 1000 / 1024) / duration << ")" << endl;
      }
      if (pagePrint) cout << "Page:" << endl << endl << page << endl;
      cout << "------------------------------------------------------------------------" << endl;
    }
  }
  delete(f);
  return(1);
}
