/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Utility functions to handle Feeder parameters
 *
 * Sriram Raghavan <rsram@cs.stanford.edu>
 *
 */

#ifndef __FEEDERPARAMS_H__
#define __FEEDERPARAMS_H__

#include <cctype>
#include <cstdlib>
#include "Url.h"
#include "Feeder.h"

/*
 * Parameters currently accepted in the query-string of a feederURI:
 * 
 *   compress=1 or compress=0        -> to receive compressed/uncompressed pages respectively
 *   compressedRepo=1 or 0           -> indicate whether repository is compressed or not
 *   numPages=X                      -> to receive "X" pages, X=-1 feeds all known pages
 *   offset=Y                        -> to begin receiving pages from specified offset
 *   docID=Z                         -> set the initial docID to "Z"
 *   sites=path_to_file              -> path to a file that lists the sites to be streamed out
 *   firstSite=name_of_site          -> the site from which to begin streaming
 *   lastSite=name_of_site           -> the last site to be streamed out
 *
 * Defaults are (compress=0, compressedRepo=1, numPages=-1, offset=0, docID = 0)
 * The "sites" parameter must be part of the query-string of any valid rep:// URI.
 * Note that the tuple (firstSite,offset) allows restart from any arbitrary point
 * in the repository. If "firstSite" is missing, streaming will begin from the first
 * site listed in the sitesFile. If "lastSite" is missing, streaming will continue 
 * until the last site in the sitesFile is streamed out. One, both, or none of 
 * firstSite and lastSite can be used in a query-string.
 *
 * FeederParams consists of a bunch of static functions that handle these defaults
 * and return the values of the query parameters. There is one function per parameter.
 */

class FeederParams {
  
 public:

  static int numPages(Url::NVMap queryParams)
  {
    int numPages = -1;
    if (queryParams.find("numPages") != queryParams.end()) 
      numPages = atoi(queryParams["numPages"].c_str());
    return(numPages);
  }

  static bool compress(Url::NVMap queryParams)
  {
    bool compress = false;
    if (queryParams.find("compress") != queryParams.end())
      compress = (queryParams["compress"] == "0" ? false : true);
    return(compress);
  }

  static unsigned long long offset(Url::NVMap queryParams)
  {    
    unsigned long long offset = 0;
    if (queryParams.find("offset") != queryParams.end()) 
      offset = strtoull(queryParams["offset"].c_str(), NULL, 0);
    return(offset);
  }

  static bool compressedRepo(Url::NVMap queryParams)
  {
    bool compressedRepo = true;
    if (queryParams.find("compressedRepo") != queryParams.end())
      compressedRepo = (queryParams["compressedRepo"] == "0" ? false : true);
    return(compressedRepo);
  }

  static DocIdType docID(Url::NVMap queryParams)
  {
    DocIdType docID = 0;
    if (queryParams.find("docID") != queryParams.end()) 
      docID = atoi(queryParams["docID"].c_str());
    return(docID);
  }

  static std::string sites(Url::NVMap queryParams)
  {
    std::string sites = "";
    if (queryParams.find("sites") != queryParams.end())
      sites = queryParams["sites"];
    return(sites);
  }

  static std::string firstSite(Url::NVMap queryParams)
  {
    std::string firstSite = "";
    if (queryParams.find("firstSite") != queryParams.end())
      firstSite = queryParams["firstSite"];
    return(firstSite);
  }

  static std::string lastSite(Url::NVMap queryParams)
  {
    std::string lastSite = "";
    if (queryParams.find("lastSite") != queryParams.end())
      lastSite = queryParams["lastSite"];
    return(lastSite);
  }

};

#endif
