/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Factory for feeders
 *
 */

#ifndef __FEEDERFACTORY_H__
#define __FEEDERFACTORY_H__

#include <fstream>
#include <string>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include "Feeder.h"
#include "Url.h"

// The feeders
#include "NetworkFeeder.h"
#include "WebCatFeeder.h"
#include "FileFeeder.h"

using std::transform;

/*
 * To instantiate a feeder, invoke the static create_feeder function
 * with one of the following kinds of sources:
 *
 *   << THIS VERSION IS DEPRECATED >>
 *   "rep://dummy_host/path_to_rep_file?query-string"      path to repository file
 *   << END DEPRECATED>>
 *
 *   "net://somehost:someport/?query-string"                  uri where a distributor is running
 *   "rep://dummy_host/path_to_repository_root?query-string   filesystem path to the location of the repository
 *   "file://dummy_host/path_to_input_file?query-string"      path to delimited webpages
 *
 * See FeederParams.h for a description of the parameters that can be used 
 * in the query string and their default values.
 */

class FeederFactory {
  
 public:

  static Feeder* create_feeder(string source) 
  {
    Feeder* feeder;

    // Get the url scheme and convert to lower case
    Url::ParsedUrl url(source);
    string scheme = url.getScheme();
    std::transform(scheme.begin(), scheme.end(), scheme.begin(), ToLower());

    // Instantiate appropriate type of feeder depending on scheme
    if (scheme == "net") feeder = new NetworkFeeder(source);
    else if (scheme == "rep") feeder = new WebCatFeeder(source);
    else if (scheme == "file") feeder = new FileFeeder(source);
    else {
      cerr << "Unknown feeder source: " << source << endl;
      feeder = NULL;
    }
    if (feeder != NULL) {
      if (! feeder->isInitialized()) {
        cerr << "FeederFactory: Error initializing feeder " << source << endl;
        feeder = NULL;
      }
    }
    return feeder;
  }

};

#endif
