/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef _NetworkFeeder_h_
#define _NetworkFeeder_h_

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "Feeder.h"
#include "repository.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <string>
#include <unistd.h>

class NetworkFeeder : public Feeder {
private :
  bool initialized; 
  char* buffer;
  char* url;
  char* timeStamp;
  unsigned long long offset;
  DocIdType docId;
  char outgoingDocType;
  int pageSize;

  int count;
  int sockfd; 
  bool compress;
  char* incomingBuffer;
  char incomingDocType;
  int incomingPageSize;

  bool doCompression() {
    return ( ((incomingDocType & COMPRESSED_TYPE) == 0) && compress);
  }

  bool doUncompression() {
    return ( ((incomingDocType & COMPRESSED_TYPE) != 0) && !compress);
  }

  void initialize(const char *hostname, int port, int numPages, bool compress);
   
public :
  NetworkFeeder(std::string feederURI);
  NetworkFeeder(const char *hostname, int port, int numPages, bool compress) 
  {
    initialize(hostname, port, numPages, compress);
  }
  virtual ~NetworkFeeder();

  bool isInitialized()             { return initialized; }
  const char* getData()            { return (const char *)buffer; }
  int getDataSize()                { return pageSize; }
  const char* getURL()             { return url; }
  DocIdType getDocId()             { return docId; }
  char getDocType()                { return outgoingDocType; }
  const char *getTimestamp()       { return (const char *)timeStamp; }
  unsigned long long getOffset()   { return offset; }

  bool next();
};

#endif
