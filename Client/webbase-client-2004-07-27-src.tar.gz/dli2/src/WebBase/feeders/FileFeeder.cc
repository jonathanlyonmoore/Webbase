/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Implementation of Feeder interface for flat files
 *
 * Author: Taher H. Haveliwala
 */

#include <iostream>
#include <string>
#include <algorithm>
#include "Url.h"
#include "FeederParams.h"
#include "FileFeeder.h"

FileFeeder::FileFeeder(string feederURI)
{
  // Parse uri and check the scheme
  Url::ParsedUrl url(feederURI);
  string scheme = url.getScheme();
  std::transform(scheme.begin(), scheme.end(), scheme.begin(), ToLower());
  if (scheme != "file") {
    cerr << "FileFeeder: uri scheme is not 'file'" << endl;
    exit(1);
  }

  // Check the compress parameter and raise error if it is set
  Url::NVMap queryParams = url.getQueryParameters();
  if (FeederParams::compress(queryParams)) {
    cerr << "FileFeeeder does not support compressed pages " << endl;
    exit(1);
  } 

  // Extract parameters and call the initialization function
  string filename = url.getPath().getPathName();
  cerr << "Attempting to read from flat file: " << filename << endl;
  initialize(filename, FeederParams::numPages(queryParams));
}


void FileFeeder::initialize(string filename, int max_pages0) {
  input.open(filename.c_str());

  if(input.fail()) {
    cerr << "Could not open: " << filename << " for input" << endl;
    exit(1);
  }

  string delimiter;
  getline(input, delimiter);

  if(delimiter != DELIMITER) {
    cerr << "Incorrect delimiter: " << delimiter << endl;
    exit(1);
  }

  num_pages = 0;
  done = false;
  max_pages = max_pages0;
  offset = 0;
}

bool FileFeeder::next() {
  data = "";

  if(num_pages == max_pages) {
    cerr << "finished!" << endl;
    done = true;
  }
  
  if(done) return false;

  int lineNum = 0;

  string buf;

  // get URL  
  getline(input, buf);
  if(input.fail()) {
    cerr << "input failed" << endl;
    done = true;
    return false;
  }
  url = "";
  if(buf.size() > 5) url = buf.substr(5);

  // get timestamp
  getline(input, buf);
  if(input.fail()) {
    cerr << "input failed" << endl;
    done = true;
    return false;
  }
  timeStamp = "";
  if(buf.size() > 6) timeStamp = buf.substr(6);

  // get offset
  getline(input, buf);
  if(input.fail()) {
    cerr << "input failed" << endl;
    done = true;
    return false;
  }
  string offsetString = "";
  if (buf.size() > 10) offsetString = buf.substr(10);
  offset = strtoull(offsetString.c_str(), NULL, 0);

  // look for blank line
  do { 
    getline(input, buf); 
  } while(!input.fail() && buf != "");

  for(getline(input, buf); 
      buf != DELIMITER; 
      getline(input, buf)) { 
    
    if(input.eof()) {
      break;
    }
    if(input.fail()) {
      cerr << "input FAILED" << endl;
      break;
    }
    
    data += buf;
    data += "\n";
  }
  
  num_pages++;  lineNum = 0;
  //    fprintf(stderr, ".");    
  if(num_pages % 10000 == 0) { cerr << num_pages << " pages" << endl; }

  return true;
}

