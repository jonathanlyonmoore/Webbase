/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
#ifndef _Distributor_h_
#define _Distributor_h_

#include "Feeder.h"
#include "Utils.h"
#include <pthread.h>

pthread_mutex_t pageMutex;
pthread_mutex_t logMutex;
pthread_mutex_t clientCountMutex;

int DEFAULT_MONITOR_INTERVAL = 10 * 1000;              // 10 secs
int DEFAULT_MAX_ACCESS_INTERVAL = 30 * 60 * 1000;      // 30 minutes
int DEFAULT_MAX_NO_CLIENT_TIME =  30 * 60 * 1000;      // 30 minutes

void *serviceClient(void *clientParams);
void *acceptClients(void *dist);

class Distributor {
private:
  Feeder *feeder;
  int numTransmitted;
  int port;
  char docType;
  long long startTime, chunkStartTime;
  long chunkSize, totalSize;

public:
  int monitor_interval, max_access_interval, max_no_client_time;
  long long accessTime, noClientTime;
  int clientCount;

  Distributor(Feeder *feeder, int port);
  void setParams(int monitor_interval, int max_access_interval, int max_no_client_time);
  bool getNext(char *url, char *buffer, int *bufSize, DocIdType *dID, unsigned long long *offset,
               char *timeStamp);
  void addToThroughput(int size);
  void logThroughput();
  void updateClientCount(int c);

  ~Distributor()             {  delete(feeder);    }
  char getDocType()          {  return docType;    }
  int getPort()              {  return port;       }
};

struct ClientParams {
  int sockfd;
  pthread_t threadID;
  Distributor* dist;
  
  ClientParams(int sockfd, pthread_t threadID, Distributor* dist) {
    this->sockfd = sockfd;
    this->threadID = threadID;
    this->dist = dist;
  }
};

#endif
