/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*********************************************************************************
 *                          Distributor
 * 
 * Program to read the repository and distribute the pages to a bunch of 
 * feeder clients across the network. Can handle any number of clients 
 * (subject to memory and thread limits) each of which can connect and disconnect 
 * at random. Multi-threaded implementation using POSIX threads with one thread
 * per client, a separate thread for accepting new connections, and another
 * monitor thread that handles "distributor suicide" and throughput logging.
 *
 * Author : Sriram Raghavan <rsram@cs.stanford.edu>
 *********************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "Distributor.h"
#include "Feeder.h"
#include "WebCatFeeder.h"
#include "Utils.h"
#include "TUtils.h"
#include "repository.h"
#include "confloader.h"
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string>
#include <unistd.h>
#include <getopt.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <stdlib.h>
// BEGIN SOLARIS PORT CHANGE
#include <strings.h>
// END SOLARIS PORT CHANGE

Distributor::Distributor(Feeder *feeder, int port)
{
  this->port = port;
  this->feeder = feeder;
  docType = feeder->getDocType();
  numTransmitted = clientCount = 0;

  // initialize throughput measurement variables  
  accessTime = noClientTime = startTime = chunkStartTime = Utils::currentTimeMillis();
  totalSize = chunkSize = clientCount = 0;
  
  // initialize timing parameters
  this->monitor_interval = DEFAULT_MONITOR_INTERVAL;
  this->max_access_interval = DEFAULT_MAX_ACCESS_INTERVAL;
  this->max_no_client_time = DEFAULT_MAX_NO_CLIENT_TIME;
}


void Distributor::setParams(int monitor_interval, int max_access_interval, int max_no_client_time)
{
  if (monitor_interval > 0) this->monitor_interval = monitor_interval * 1000;
  if (max_access_interval > 0) this->max_access_interval = max_access_interval * 1000;
  if (max_no_client_time > 0) this->max_no_client_time = max_no_client_time * 1000;

  cout << "Distributor: Using the following parameters " << endl;
  cout << "\t Monitor interval  = " << this->monitor_interval/1000 << " secs" << endl;
  cout << "\t Max. access interval = " << this->max_access_interval/1000 << " secs" << endl;
  cout << "\t Max. no client time  = " << this->max_no_client_time/1000 << " secs" << endl;
}


bool Distributor::getNext(char *url, char *buffer, int *bufSize,  DocIdType *dID, 
                          unsigned long long *offset, char *timeStamp) 
{
  // Get next page from feeder and set output arguments
  if (feeder->next()) {
    *bufSize = feeder->getDataSize();
    *dID = feeder->getDocId();
    *offset = feeder->getOffset();
    strcpy(timeStamp, feeder->getTimestamp());
    strcpy(url, feeder->getURL());
    memcpy(buffer, feeder->getData(), *bufSize);
    accessTime = Utils::currentTimeMillis();
    addToThroughput(*bufSize);
    numTransmitted++;
    return(true);
  }
  return(false);
}


void Distributor::updateClientCount(int c)      
{  
  pthread_mutex_lock(&clientCountMutex); 
  clientCount += c;  
  if (clientCount == 0) noClientTime = Utils::currentTimeMillis();
  pthread_mutex_unlock(&clientCountMutex); 
}


void Distributor::addToThroughput(int size)
{
  pthread_mutex_lock(&logMutex);
  chunkSize += size;
  totalSize += size;
  pthread_mutex_unlock(&logMutex);
}


void Distributor::logThroughput() 
{
  // nothing to print if no clients
  pthread_mutex_lock(&clientCountMutex); 
  if (clientCount <= 0) {
    pthread_mutex_unlock(&clientCountMutex); 
    return;
  }
  pthread_mutex_unlock(&clientCountMutex); 

  pthread_mutex_lock(&logMutex);
  chunkSize = abs( chunkSize );
  // Calculate and print throughput parameters
  long long currentTime = Utils::currentTimeMillis();
  float rate = (float)chunkSize * 1000/1024/(currentTime - chunkStartTime);
  
  cout << numTransmitted << " pages in " << (currentTime - startTime)/1000 << " secs. ";
  cout << chunkSize << " bytes in last " << (currentTime - chunkStartTime)/1000 << "secs. ";
  cout << "Rate = " << rate << " kBps" << endl;

  float overallRate = (float)totalSize * 1000/1024/(currentTime - startTime);
  cout << "Overall= " << overallRate << " kBps" << endl;

  // Reset chunk times and sizes
  chunkStartTime = Utils::currentTimeMillis();
  chunkSize = 0;

  pthread_mutex_unlock(&logMutex);
}


/*********************************************************************************
 * Monitoring function executed by the monitor thread. Periodically wakes up,
 * causes distributor to log throughput information, and goes back to sleep again.
 *********************************************************************************/
void *monitor(void *d)
{
  Distributor* dist = (Distributor*)d;
  long long currentTime;

  cout << "Monitor thread activated" << endl;
  dist->logThroughput();
  while(1) {
    TUtils::threadSleep(dist->monitor_interval);
    dist->logThroughput();
    currentTime = Utils::currentTimeMillis();

    pthread_mutex_lock(&clientCountMutex); 
    if ((dist->clientCount == 0) && (currentTime >= dist->noClientTime + dist->max_no_client_time)) {
      cout << "\n\nDistributor Monitor Thread: No clients - timeout. Shutting down." << endl;
      exit(1);
    }
    pthread_mutex_unlock(&clientCountMutex);

    if (currentTime >= dist->accessTime + dist->max_access_interval) {
      cout << "\n\nDistributor Monitor Thread: No page access - timeout. Shutting down." << endl;
      exit(1);
    }

  }
}


/*********************************************************************************
 * Function executed by client service thread. Repeatedly, gets next page and
 * associated metadata from the distributor and writes to the client socket.
 *********************************************************************************/
void *serviceClient(void *clientParams)
{
  ClientParams *cparams = (ClientParams *)clientParams;
  int sockfd = cparams->sockfd;
  pthread_t threadID = cparams->threadID;
  Distributor* dist = cparams->dist;
  delete cparams;

  char *buffer = new char[MAX_FILE_SIZE+1];
  char *url = new char[MAX_URL_SIZE+1];
  char *timeStamp = new char[TIMESTAMP_LENGTH+1];
  unsigned long long offset;
  int bufSize;
  DocIdType docId;
  char docType = dist->getDocType();

  dist->updateClientCount(1);

  if ((timeStamp == NULL) || (buffer == NULL) || (url == NULL)) {
    cerr << "Distributor-service thread : Unable to allocate memory for buffers" << endl;
    dist->updateClientCount(-1);
    pthread_exit(NULL);
  }

  // Receive page count from client
  int net_pageCount, pageCount;
  if (! Utils::readn (sockfd, (char *)&net_pageCount, sizeof(net_pageCount))) {
    cerr << "Distributor-service thread: Unable to get page count value from client" << endl;
    dist->updateClientCount(-1);
    pthread_exit(NULL);
  }
  else {
    Utils::readNumber((const char *)&net_pageCount, (char *)&pageCount, sizeof(pageCount));
    cout << "Distributor-service thread : Received page count from client = " << pageCount << endl;
  }

  // Send the docType to the client
  if (!Utils::writen(sockfd, (char *)&docType, sizeof(docType))) {
    cerr << "Distributor-service thread: Unable to send docType to client" << endl;
    dist->updateClientCount(-1);
    pthread_exit(NULL);
  }

  // Repeatedly, call next() on the distributor and write out to client socket
  while (pageCount != 0) {

    // Call next on the distributor within crticial section
    pthread_mutex_lock(&pageMutex);
    bool rc = dist->getNext(url, buffer, &bufSize, &docId, &offset, timeStamp);
    pthread_mutex_unlock(&pageMutex);

    // kludge our way past a bad spot
//     if (! rc) {   
//       cerr << "Found bad spot in the repository: Error code from bigfile =  " << rc << endl;
//       int mo = 100;
//       int off;
//       off = offset;cerr << endl << ">>>>> bad spot retry , add " ;cerr << mo << endl;offset = off + mo;
//       rc = dist->getNext(url, buffer, &bufSize, &docId, &offset , timeStamp);
//       if (! rc) {   
//         mo = 10000;
//         off = offset;cerr << endl << ">>>>> bad spot @ "; cerr << off  << endl;cerr << " retry , add " ;cerr << mo << endl;offset = off + mo;
//         rc = dist->getNext(url, buffer,&bufSize,&docId, &offset , timeStamp);
//         if (! rc) {   
//           mo = 100000;
//           off = offset;cerr << endl << ">>>>> bad spot @ "; cerr << off  << endl;cerr << " retry , add " ;cerr << mo << endl;offset = off + mo;
//           rc = dist->getNext(url,buffer,&bufSize,&docId, &offset ,timeStamp);
//           if (! rc) {   
//             mo = 1000000;
//             off = offset;cerr << endl << ">>>>> bad spot @ "; cerr << off  << endl;cerr << " retry , add " ;cerr << mo << endl;offset = off + mo;
//             rc = dist->getNext(url,buffer,&bufSize,&docId, &offset ,timeStamp);
//             if (! rc) {   
//               mo = 10000000;
//               off = offset;cerr << endl << ">>>>> bad spot @ "; cerr << off  << endl;cerr << " retry , add " ;cerr << mo << endl;offset = off + mo;
//               rc = dist->getNext(url,buffer,&bufSize,&docId,&offset  ,timeStamp);
//               if (!rc){cerr << endl << endl << ">>>>> Damn, I give up!" << endl; }
//             }
//           }
//         }
//       }
//     }

    // If no more pages from the distributor, cancel the thread that is
    // accepting client connections, and get out of loop
    if (! rc) {   
      pthread_cancel(threadID);  break;
    }
    buffer[bufSize] = '\0';

    // Send docID, offset, timestamp length, url length, page length, url, and 
    // page to the client in that order.
    DocIdType net_docId;
    unsigned long long net_offset;
    int net_tsLen, tsLen = strlen(timeStamp);
    int net_urlLen, urlLen = strlen(url);
    int net_pageLen, pageLen = bufSize;

    Utils::writeNumber((char *)&net_docId, (const char *)&docId, sizeof(docId));
    Utils::writeNumber((char *)&net_offset, (const char *)&offset, sizeof(offset));
    Utils::writeNumber((char *)&net_tsLen, (const char *)&tsLen, sizeof(tsLen));  
    Utils::writeNumber((char *)&net_urlLen, (const char *)&urlLen, sizeof(urlLen));
    Utils::writeNumber((char *)&net_pageLen, (const char *)&pageLen, sizeof(pageLen));
    if (! Utils::writen(sockfd, (char *)&net_docId, sizeof(net_docId))  ||
        ! Utils::writen(sockfd, (char *)&net_offset, sizeof(net_offset)) ||
        ! Utils::writen(sockfd, (char *)&net_tsLen, sizeof(net_tsLen)) ||
        ! Utils::writen(sockfd, (char *)&net_urlLen, sizeof(net_urlLen)) ||
        ! Utils::writen(sockfd, (char *)&net_pageLen, sizeof(net_pageLen)) ||
        ! Utils::writen(sockfd, timeStamp, tsLen) || 
        ! Utils::writen(sockfd, url, urlLen) || 
        ! Utils::writen(sockfd, buffer, bufSize)) {
      if (errno == EPIPE) cerr << "Distributor-service thread: Client done, closing channel" << endl;
      else perror("Distributor-service thread -- Error writing to socket");
      break;
    }

    // Decrement page count
    if (pageCount != -1) pageCount--;
  }

  // Close channel, free buffers, and thread exit
  cout << "Distributor-service thread: Done." << endl;
  close(sockfd);
  free(buffer);  free(url);  free(timeStamp);
  dist->updateClientCount(-1);
  pthread_exit(NULL);
}


/*********************************************************************************
 * Function executed by the thread that accepts client connections. For each
 * new client, accept the connection and fork off a client service thread.
 *********************************************************************************/
void *acceptClients(void *dist)
{
  // Create socket and bind to the specified port
  struct sockaddr_in addr;
  int sockfd;
  int port = ((Distributor*)dist)->getPort();
  if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    perror("Distributor - unable to create socket");
    pthread_exit(NULL);
  }
  bzero((char *)&addr, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  addr.sin_port =  htons(port);
  if (bind(sockfd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
    perror("Distributor - Unable to bind");
    pthread_exit(NULL);
  }

  // Start listening for client connections
  struct sockaddr_in cli_addr;
  unsigned int clilen = sizeof(cli_addr);
  listen(sockfd, 5);

  // For each successfully accepted client connection, create and
  // detach a client service thread
  while (1) {
    int clisockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
    if (clisockfd < 0) {
      perror("Distributor-Error in accept");
      continue;
    }
    ClientParams *clientParams = new ClientParams(clisockfd, pthread_self(), (Distributor*)dist);
    pthread_t serviceThread;
    pthread_create(&serviceThread, NULL, &serviceClient, clientParams);
    pthread_detach(serviceThread);
  }

  // Should never actually get here since this thread will keep on looping until
  // one of the client service threads does a pthread_cancel on it.
  pthread_exit(NULL);   
}


int main(int argc, char *argv[])
{
  extern char *optarg;
  extern int optind;
  int option_char;
  int port = 0;
  string feederURI = "";
  string confFile = "";
  string usageInfo = " -u <repository feeder URI> -p <port number> -f <config file>\n";

  // Process command line arguments  
  while ((option_char = getopt(argc, argv, "u:p:f:")) != EOF) {
    switch (option_char) {
      case 'u': feederURI.assign(optarg); break;
      case 'p': sscanf(optarg, "%d", &port); break;
      case 'f': confFile.assign(optarg); break;
      case '?': cerr << "Usage: " << argv[0] << usageInfo << endl;  return(-1); 
    }
  }

  // Exit if commandline arguments are invalid or incomplete
  if (confFile.empty() || feederURI.empty() || (port == 0)) {
    cerr << "Usage: " << argv[0] << usageInfo << endl; return(-1);
    return(-1);
  }

  // Instantiate a WebCatFeeder using the feeder uri
  Feeder *feeder =  new WebCatFeeder(feederURI);
  if (! feeder->isInitialized()) {
    cerr << "Distributor: Unable to initialize feeder " << feederURI << endl;
    return(-1);
  }

  // Instantiate a distributor
  Distributor* distributor = new Distributor(feeder, port);

  // Load and set configuration values
  ConfLoader cloader;
  if (! cloader.loadValues(confFile.c_str(), '=')) {
    cerr << "Distributor: Unable to load values from config file " << confFile << endl;
    return(-1);
  }
  distributor->setParams(atoi(cloader.getValue("DISTRIBUTOR_MONITOR_INTERVAL")),
                         atoi(cloader.getValue("DISTRIBUTOR_MAX_ACCESS_INTERVAL")),
                         atoi(cloader.getValue("DISTRIBUTOR_MAX_NO_CLIENT_TIME")));

  // To prevent "Broken pipe"'s when client(s) shut down
  signal(SIGPIPE, SIG_IGN);              

  system("date");

  // Initialize mutexes
  pthread_mutex_init(&pageMutex, NULL);
  pthread_mutex_init(&clientCountMutex, NULL);
  pthread_mutex_init(&logMutex, NULL);

  // Instantiate thread to accept connection requests from new clients
  pthread_t acceptClientsThread;
  pthread_create(&acceptClientsThread, NULL, &acceptClients, distributor);
  pthread_detach(acceptClientsThread);

  // Instantiate monitor thread
  pthread_t monitorThread;
  pthread_create(&monitorThread, NULL, &monitor, distributor);
  pthread_detach(monitorThread);

  // Main thread exits
  pthread_exit(NULL);
}
