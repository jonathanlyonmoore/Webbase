/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/******************************************************************************
 *                          WebCatFeeder
 * 
 * Reads pages from the repository, implementing the Feeder interface
 *
 * Author : Sriram Raghavan <rsram@cs.stanford.edu>
 *****************************************************************************/

#include "WebCatFeeder.h"
#include "FeederParams.h"
#include "TypeDetector.h"
#include "SiteEnumerator.h"
#include "Url.h"
#include <algorithm>
#include <cstdio>
#include <string>

WebCatFeeder::WebCatFeeder(std::string feederURI)
{

  initialized = false;

  Url::ParsedUrl parsedFeederURL(feederURI);
  std::string scheme = parsedFeederURL.getScheme();
  Url::NVMap queryParams = parsedFeederURL.getQueryParameters();

  // Check schema
  std::transform(scheme.begin(), scheme.end(), scheme.begin(), ToLower());
  if (scheme != "rep") {
    cerr << "WebCatFeeder: uri scheme is not 'rep'" << endl;
    return;
  }

  // Initialize site enumerator
  std::string sitesFile = FeederParams::sites(queryParams);
  std::string firstSite = FeederParams::firstSite(queryParams);
  std::string lastSite = FeederParams::lastSite(queryParams);
  if (sitesFile.empty()) {
    cerr << "WebCatFeeder: Bad feeder uri - cannot initialize without a valid sites file" << endl;
    return;
  }
  siteEnum = new SiteEnumerator(sitesFile, firstSite, lastSite);
  if (! siteEnum->hasMoreSites()) {
    if (firstSite.length() > 0) cerr << "WebCatFeeder: Unable to find " << firstSite << " in sites file" << endl;
    else cerr << "WebCatFeeder: Failure to initialize siteEnumerator" << endl;
    return;
  }

  // allocate and initialize buffers to store content during streaming
  buffer = new char[MAX_FILE_SIZE + 1];
  timeStamp = new char[TIMESTAMP_LENGTH + 1];
  if (buffer == NULL || timeStamp == NULL) {
    cerr << "WebCatFeeder: Unable to allocate memory for internal buffers" << endl;
    return;
  }
  buffer[0] = '\0';
  timeStamp[0] = '\0';
  size = 0;

  // Initialize other parameters
  std::string rootDir = parsedFeederURL.getPath().getPathName();
  offset = FeederParams::offset(queryParams);
  docID = FeederParams::docID(queryParams) - 1; // docID gets incr. every time page is retrieved. so do -1 now
  count = FeederParams::numPages(queryParams);
  compress = FeederParams::compress(queryParams);
  compressedRepo = FeederParams::compressedRepo(queryParams);
  url = "";

  // Set compression status of repository and outgoing document type
  if (!compressedRepo && compress) {
    cerr << "WebCatFeeder: Compressed pages requested from uncompressed repository" << endl;
    return;
  }
  docType = 0;
  if (compress) docType |= COMPRESSED_TYPE;

  // Instantiate repository, set first site, and seek
  repo = new repository(rootDir, compressedRepo, rootDir);
  while (true) {
    currentSite = siteEnum->getNextSite();
    if ( 
	   repo->set_site(currentSite,TypeDetector::TEXT ) < 0 
	   //&& repo->set_site(currentSite,TypeDetector::IMAGE) < 0 
	   //&& repo->set_site(currentSite,TypeDetector::AUDIO) < 0 
	)
      cerr << "WebCatFeeder: Unable to call set_site on repository for site = " << currentSite << endl;
    else break;
    if (! siteEnum->hasMoreSites()) {
      cerr << "WebCatFeedder: Ran out of sites" << endl;
      return;
    }
  }

  if (repo->seek(offset, SEEK_SET) < 0) {
    cerr << "WebCatFeeder: Could not seek " << offset << " , when initializing feeder" << endl;
    return;
  }

  initialized = true;
}

WebCatFeeder::~WebCatFeeder() {
  delete repo;
  delete siteEnum;
  delete [] buffer;
  delete [] timeStamp;
}

bool WebCatFeeder::seek(unsigned long long seekOffset) 
{
  if (repo->seek(seekOffset, SEEK_SET) < 0) {
    cerr << "WebCatFeeder: Could not seek to " << seekOffset << endl;
    return false;
  }
  return true;
}


bool WebCatFeeder::next()
{
  if ((!initialized) || (count == 0)) return false;   // count = 0 => required number of pages fed already

  // Read  from repository
  int  rc, bufSize = MAX_FILE_SIZE;
  time_t procTime;
  offset = repo->tell();

  // Move on to next site
  if ((rc = repo->read(url, procTime, buffer, bufSize, !compress)) < 0) {
    cerr << "WebCatFeeder: Error when reading from current site. Return code " << rc
         << " Moving on to next site...." << endl;
    bufSize = MAX_FILE_SIZE;

    while(true) {
      if (! siteEnum->hasMoreSites()) {
        cerr << "WebCatFeedder: Ran out of sites" << endl;
        return false;
      }
      currentSite = siteEnum->getNextSite();
      if(!repo->set_site(currentSite,TypeDetector::TEXT)) {
        cerr << "WebCatFeeder: Unable to set site to " << currentSite << endl;
        cerr << "skipping" << endl;
      } else {
        break;
      }
    }
    return this->next();
  }
  
  // read was successful. continue with current site
  else {
    this->size = bufSize;
    buffer[bufSize] = '\0';
    strncpy(timeStamp, ctime(&procTime), TIMESTAMP_LENGTH);
    timeStamp[TIMESTAMP_LENGTH] = '\0';
    if (count != -1) count--;
    docID++;
  }
  return true;
}
