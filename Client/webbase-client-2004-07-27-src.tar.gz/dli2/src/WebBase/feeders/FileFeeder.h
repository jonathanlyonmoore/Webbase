/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * Feeder interface for plain flatfiles
 *
 * Author: Taher H. Haveliwala
 */

#ifndef __FILEFEEDER_H__
#define __FILEFEEDER_H__

#include <fstream>
#include <string>
#include "Feeder.h"

#ifndef DELIMITER
#define DELIMITER "==P=>>>>=i===<<<<=T===>=A===<=!Junghoo!==>"
#endif

class FileFeeder : public Feeder {
 public:
  FileFeeder(string feederURI);
  virtual ~FileFeeder() {}
  FileFeeder(string filename, int max_pages0)  {  initialize(filename, max_pages0); }

  bool isInitialized() { return true; }
  const char* getData() { return data.c_str(); }
  int getDataSize() { return data.size(); }
  const char* getURL() { return url.c_str(); }
  DocIdType getDocId() { return num_pages; }
  char getDocType() { return 0; }
  const char *getTimestamp() { return timeStamp.c_str(); }
  unsigned long long getOffset() { return offset; }

  bool next();

 private:
  void initialize(string filename, int max_pages0);

  ifstream input;

  int max_pages, num_pages;
  bool done;

  string data;
  string url;
  string timeStamp;
  unsigned long long offset;
};

#endif // __FILEFEEDER_H__
