#
# Some useful utilities for WebBase access through perl
#
# Author: Taher H. Haveliwala (taherh@cs.stanford.edu)
#

package WB::Properties;

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw();
@EXPORT_OK = qw();

use strict;
use warnings;

use DBI;
use FileHandle;
use IPC::Open2;
use Socket;

my $wbroot = "/u/taherh/research/latest/WebBase/";

my %sth;

# open up ipc for url2hash and normalize
sub open_url2hash {
  open2(\*URL2HASH_R, \*URL2HASH_W,
        "$wbroot/bin/urlHasher signed loseslash") or
          die $!;
  URL2HASH_W->autoflush(1);
}

sub open_normalize {
  open2(\*NORMALIZE_R, \*NORMALIZE_W,
        "$wbroot/bin/normalize") or
          die $!;
  URL2HASH_W->autoflush(1);  
}

# connect to the database server
sub db_connect {
  my $dbh = DBI->connect("dbi:Pg:dbname=webbase;host=oh", "webbase", "wbwb");

  # prepare any canned statements here
  $sth{'pagerank'} = $dbh->prepare(q{
                      SELECT rank 
                      FROM PageRank 
                      WHERE DocId = ?::bigint
		    });

  $sth{'title'} = $dbh->prepare(q{
                      SELECT title 
                      FROM Titles 
                      WHERE DocId = ?::bigint or
			    DocId = ?::bigint + 1 
		      ORDER BY DocId DESC
		    });

  $sth{'offset'} = $dbh->prepare(q{
                      SELECT ArchiveOffset 
                      FROM OffsetLookup
                      WHERE DocId = ?::bigint or
			    DocId = ?::bigint + 1 
		      ORDER BY DocId DESC
		    });

}

sub url2hash {
  open_url2hash() unless defined fileno URL2HASH_W;

  local $/ = "\n";
  my $url = shift;
  print URL2HASH_W "$url\n";
  my $hash = <URL2HASH_R>;
  chomp $hash;
  return $hash;
}

sub normalize {
  open_normalize() unless defined fileno NORMALIZE_W;

  local $/ = "\n";
  my $url = shift;
  print NORMALIZE_W "$url\n";
  my $norm_url = <NORMALIZE_R>;
  chomp $norm_url;
  return $norm_url;
}

sub get_pagerank {
  db_connect() unless exists $sth{'pagerank'};

  my $url = shift;
  my $hash = url2hash($url);
  return 0 if($hash == 0);

  $sth{'pagerank'}->execute($hash);
  my $r = $sth{'pagerank'}->fetchrow_arrayref;
  return 0 unless $r;

  return $$r[0]
}

sub get_title {
  db_connect() unless exists $sth{'title'};

  my $url = shift;
  my $hash = url2hash($url);
  return "none" if($hash == 0);

  $sth{'title'}->execute($hash, $hash);
  my $r = $sth{'title'}->fetchrow_arrayref;
  return "none" unless $r;

  return $$r[0]
}

sub get_offset {
  db_connect() unless exists $sth{'offset'};

  my $url = shift;
  my $hash = url2hash($url);
  return "" if($hash == 0);

  $sth{'offset'}->execute($hash, $hash);
  my $r = $sth{'offset'}->fetchrow_arrayref;
  return "" unless $r;

  return $$r[0]
}

sub get_content {
  *C_SOCK = IO::Socket::INET->new("eh.stanford.edu:5005")
    unless defined fileno C_SOCK;

  my $url = shift;

  print C_SOCK "C $url\n";
  my $DELIM = <C_SOCK>;
  local $/ = "\nEND_WB_TRANS\n";
  my $content = <C_SOCK>;
  chomp($content);
  return "Sorry, not in cache" if($DELIM eq "NO_INFO\n");
  local $/ = $DELIM;
  chomp($content);
  return $content;
}

1;
