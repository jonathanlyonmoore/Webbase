/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/******************************************************************************
 * Method definitions for classes defined in the Url namespace
 *
 * Adapted by Sriram Raghavan <rsram@cs.stanford.edu> from original 
 * implementation by G. Andrew Mangogna. 
 * (http://www.slip.net/~andrewm/c++-library/)
 *****************************************************************************/

#include "Url.h"

using namespace std;

const char Url::UrlEncoder::_nonGraphicMask = 0x01 ;
const char Url::UrlEncoder::_unsafeMask = 0x02 ;
const char Url::UrlEncoder::_reservedMask = 0x04 ;
const char Url::UrlEncoder::_urlCharTypes[256] =
  {
    _nonGraphicMask,			// 0
    _nonGraphicMask,			// 1
    _nonGraphicMask,			// 2
    _nonGraphicMask,			// 3
    _nonGraphicMask,			// 4
    _nonGraphicMask,			// 5
    _nonGraphicMask,			// 6
    _nonGraphicMask,			// 7
    _nonGraphicMask,			// 8
    _nonGraphicMask,			// 9
    _nonGraphicMask,			// 10
    _nonGraphicMask,			// 11
    _nonGraphicMask,			// 12
    _nonGraphicMask,			// 13
    _nonGraphicMask,			// 14
    _nonGraphicMask,			// 15
    _nonGraphicMask,			// 16
    _nonGraphicMask,			// 17
    _nonGraphicMask,			// 18
    _nonGraphicMask,			// 19
    _nonGraphicMask,			// 20
    _nonGraphicMask,			// 21
    _nonGraphicMask,			// 22
    _nonGraphicMask,			// 23
    _nonGraphicMask,			// 24
    _nonGraphicMask,			// 25
    _nonGraphicMask,			// 26
    _nonGraphicMask,			// 27
    _nonGraphicMask,			// 28
    _nonGraphicMask,			// 29
    _nonGraphicMask,			// 30
    _nonGraphicMask,			// 31
    _unsafeMask,				  // 32 == SPACE
    0,							      // 33 == !
    _unsafeMask,				  // 34 == "
    _reservedMask,				// 35 == #
    0,							      // 36 == $
    _reservedMask,				// 37 == %
    _reservedMask,				// 38 == &
    0,							// 39 == '
    0,							// 40 == (
    0,							// 41 == )
    0,							// 42 == *
    0,							// 43 == +
    0,							// 44 == ,
    0,							// 45 == -
    0,							// 46 == .
    _reservedMask,				// 47 == /
    0,							// 48 == 0
    0,							// 49 == 1
    0,							// 50 == 2
    0,							// 51 == 3
    0,							// 52 == 4
    0,							// 53 == 5
    0,							// 54 == 6
    0,							// 55 == 7
    0,							// 56 == 8
    0,							// 57 == 9
    _reservedMask,				// 58 == :
    _reservedMask,				// 59 == ;
    _unsafeMask,				// 60 == <
    _reservedMask,				// 61 == =
    _unsafeMask,				// 62 == >
    _reservedMask,				// 63 == ?
    _reservedMask,				// 64 == @
    0,							// 65 == A
    0,							// 66 == B
    0,							// 67 == C
    0,							// 68 == D
    0,							// 69 == E
    0,							// 70 == F
    0,							// 71 == G
    0,							// 72 == H
    0,							// 73 == I
    0,							// 74 == J
    0,							// 75 == K
    0,							// 76 == L
    0,							// 77 == M
    0,							// 78 == N
    0,							// 79 == O
    0,							// 80 == P
    0,							// 81 == Q
    0,							// 82 == R
    0,							// 83 == S
    0,							// 84 == T
    0,							// 85 == U
    0,							// 86 == V
    0,							// 87 == W
    0,							// 88 == X
    0,							// 89 == Y
    0,							// 90 == Z
    _unsafeMask,				// 91 == [
    _unsafeMask,				// 92 == backslash
    _unsafeMask,				// 93 == ]
    _unsafeMask,				// 94 == ^
    0,							// 95 == _
    _unsafeMask,				// 96 == `
    0,							// 97 == a
    0,							// 98 == b
    0,							// 99 == c
    0,							// 100 == d
    0,							// 101 == e
    0,							// 102 == f
    0,							// 103 == g
    0,							// 104 == h
    0,							// 105 == i
    0,							// 106 == j
    0,							// 107 == k
    0,							// 108 == l
    0,							// 109 == m
    0,							// 110 == n
    0,							// 111 == o
    0,							// 112 == p
    0,							// 113 == q
    0,							// 114 == r
    0,							// 115 == s
    0,							// 116 == t
    0,							// 117 == u
    0,							// 118 == v
    0,							// 119 == w
    0,							// 120 == x
    0,							// 121 == y
    0,							// 122 == z
    _unsafeMask,				// 123 == {
    _unsafeMask,				// 124 == |
    _unsafeMask,				// 125 == }
    _unsafeMask,				// 126 == ~
    _nonGraphicMask,			// 127 == DEL
    _nonGraphicMask,			// 128
    _nonGraphicMask,			// 129
    _nonGraphicMask,			// 130
    _nonGraphicMask,			// 131
    _nonGraphicMask,			// 132
    _nonGraphicMask,			// 133
    _nonGraphicMask,			// 134
    _nonGraphicMask,			// 135
    _nonGraphicMask,			// 136
    _nonGraphicMask,			// 137
    _nonGraphicMask,			// 138
    _nonGraphicMask,			// 139
    _nonGraphicMask,			// 140
    _nonGraphicMask,			// 141
    _nonGraphicMask,			// 142
    _nonGraphicMask,			// 143
    _nonGraphicMask,			// 144
    _nonGraphicMask,			// 145
    _nonGraphicMask,			// 146
    _nonGraphicMask,			// 147
    _nonGraphicMask,			// 148
    _nonGraphicMask,			// 149
    _nonGraphicMask,			// 150
    _nonGraphicMask,			// 151
    _nonGraphicMask,			// 152
    _nonGraphicMask,			// 153
    _nonGraphicMask,			// 154
    _nonGraphicMask,			// 155
    _nonGraphicMask,			// 156
    _nonGraphicMask,			// 157
    _nonGraphicMask,			// 158
    _nonGraphicMask,			// 159
    _nonGraphicMask,			// 160
    _nonGraphicMask,			// 161
    _nonGraphicMask,			// 162
    _nonGraphicMask,			// 163
    _nonGraphicMask,			// 164
    _nonGraphicMask,			// 165
    _nonGraphicMask,			// 166
    _nonGraphicMask,			// 167
    _nonGraphicMask,			// 168
    _nonGraphicMask,			// 169
    _nonGraphicMask,			// 170
    _nonGraphicMask,			// 171
    _nonGraphicMask,			// 172
    _nonGraphicMask,			// 173
    _nonGraphicMask,			// 174
    _nonGraphicMask,			// 175
    _nonGraphicMask,			// 176
    _nonGraphicMask,			// 177
    _nonGraphicMask,			// 178
    _nonGraphicMask,			// 179
    _nonGraphicMask,			// 180
    _nonGraphicMask,			// 181
    _nonGraphicMask,			// 182
    _nonGraphicMask,			// 183
    _nonGraphicMask,			// 184
    _nonGraphicMask,			// 185
    _nonGraphicMask,			// 186
    _nonGraphicMask,			// 187
    _nonGraphicMask,			// 188
    _nonGraphicMask,			// 189
    _nonGraphicMask,			// 190
    _nonGraphicMask,			// 191
    _nonGraphicMask,			// 192
    _nonGraphicMask,			// 193
    _nonGraphicMask,			// 194
    _nonGraphicMask,			// 195
    _nonGraphicMask,			// 196
    _nonGraphicMask,			// 197
    _nonGraphicMask,			// 198
    _nonGraphicMask,			// 199
    _nonGraphicMask,			// 200
    _nonGraphicMask,			// 201
    _nonGraphicMask,			// 202
    _nonGraphicMask,			// 203
    _nonGraphicMask,			// 204
    _nonGraphicMask,			// 205
    _nonGraphicMask,			// 206
    _nonGraphicMask,			// 207
    _nonGraphicMask,			// 208
    _nonGraphicMask,			// 209
    _nonGraphicMask,			// 210
    _nonGraphicMask,			// 211
    _nonGraphicMask,			// 212
    _nonGraphicMask,			// 213
    _nonGraphicMask,			// 214
    _nonGraphicMask,			// 215
    _nonGraphicMask,			// 216
    _nonGraphicMask,			// 217
    _nonGraphicMask,			// 218
    _nonGraphicMask,			// 219
    _nonGraphicMask,			// 220
    _nonGraphicMask,			// 221
    _nonGraphicMask,			// 222
    _nonGraphicMask,			// 223
    _nonGraphicMask,			// 224
    _nonGraphicMask,			// 225
    _nonGraphicMask,			// 226
    _nonGraphicMask,			// 227
    _nonGraphicMask,			// 228
    _nonGraphicMask,			// 229
    _nonGraphicMask,			// 230
    _nonGraphicMask,			// 231
    _nonGraphicMask,			// 232
    _nonGraphicMask,			// 233
    _nonGraphicMask,			// 234
    _nonGraphicMask,			// 235
    _nonGraphicMask,			// 236
    _nonGraphicMask,			// 237
    _nonGraphicMask,			// 238
    _nonGraphicMask,			// 239
    _nonGraphicMask,			// 240
    _nonGraphicMask,			// 241
    _nonGraphicMask,			// 242
    _nonGraphicMask,			// 243
    _nonGraphicMask,			// 244
    _nonGraphicMask,			// 245
    _nonGraphicMask,			// 246
    _nonGraphicMask,			// 247
    _nonGraphicMask,			// 248
    _nonGraphicMask,			// 249
    _nonGraphicMask,			// 250
    _nonGraphicMask,			// 251
    _nonGraphicMask,			// 252
    _nonGraphicMask,			// 253
    _nonGraphicMask,			// 254
    _nonGraphicMask,			// 255
  };


string Url::UrlEncoder::encode(const string& s)
{
	string encoded;
	for (string::const_iterator s_iter = s.begin(); s_iter != s.end();	++s_iter)	{
		char c = *s_iter;
		if (_urlCharTypes[c] & (_nonGraphicMask | _unsafeMask | _reservedMask))	{
			encoded += '%';
			encoded += toASCII((c >> 4) & 0x0f);
			encoded += toASCII(c & 0x0f);
		}
		else encoded += c;
	}
	return encoded;
}


string Url::UrlEncoder::decode(const string& s) throw(underflow_error)
{
	string decoded;
	string::const_iterator s_end = s.end();
	for (string::const_iterator s_iter = s.begin(); s_iter != s_end; ++s_iter)	{
		char c = *s_iter;
		if (c == '%') {
			if (++s_iter != s_end) {
				char dc = fromASCII(*s_iter);
				if (++s_iter != s_end) decoded += (dc << 4) | fromASCII(*s_iter);
				else throw (underflow_error("Premature EOS while decoding"));
			}
			else throw (underflow_error("Premature EOS while decoding"));
		}	
    else decoded += c;
	}
	return decoded ;
}


char Url::UrlEncoder::fromASCII(char c)
{
	char ac = c - '0';
	if (c >= 'A' && c <= 'F')
		ac -= 'A' - '9' - 1 ;
	else if (c >= 'a' && c <= 'f')
		ac -= 'a' - '9' - 1 ;
	return ac;
}


void Url::NetworkLocation::parse(const string& netlocation)
{
	string userpart;
	string hostpart;
	string::size_type place = netlocation.find('@');

	if (place == string::npos) hostpart = netlocation;
	else {
		userpart = netlocation.substr(0, place);
		hostpart = netlocation.substr(place + 1);
	}

	if (! userpart.empty()) {
		place = userpart.find(':');
		if (place == string::npos) setUser(UrlEncoder::decode(userpart));
		else {
			setUser(UrlEncoder::decode(userpart.substr(0, place)));
			setPassword(UrlEncoder::decode(userpart.substr(place + 1)));
		}
	}

	place = hostpart.find(':');
	if (place == string::npos) setHost(UrlEncoder::decode(hostpart));
	else {
		setHost(UrlEncoder::decode(hostpart.substr(0, place)));
		setPort(UrlEncoder::decode(hostpart.substr(place + 1)));
	}
}


string Url::NetworkLocation::getEncoded() const
{
	string encoded(UrlEncoder::encode(getUser()));
	string field = UrlEncoder::encode(getPassword());
	if (! field.empty())	{
		encoded += ':';
		encoded += field;
	}

	if (! encoded.empty()) 	encoded += '@';

	encoded += UrlEncoder::encode(getHost());
	field = UrlEncoder::encode(getPort());
	if (! field.empty())	{
		encoded += ':';
		encoded += field;
	}

	return encoded;
}


void Url::UrlPath::parse(const string& path)
{
	_leadingSlash = false;
	_pathComponents.clear();

	if (! path.empty())	{
		string::size_type place = 0;
		if (path[place] == '/')	{
			_leadingSlash = true;
			++place;
		}

		string::size_type end = path.find('/', place);
		string component = path.substr(place, end - place);
		if (! component.empty()) _pathComponents.push_back(UrlEncoder::decode(component));
		place = end;

		while (place != string::npos)	{
			end = path.find('/', ++place);
			component = path.substr(place, end - place);
			if (! component.empty()) _pathComponents.push_back(UrlEncoder::decode(component));
			place = end;
		}
	}
}


string Url::UrlPath::getEncoded() const
{
	string encoded;
	if (_leadingSlash) encoded += '/';

	vector<string>::const_iterator p_iter = _pathComponents.begin();
	vector<string>::const_iterator p_end = _pathComponents.end();

	if (p_iter != p_end)	{
		encoded += UrlEncoder::encode(*p_iter);
		++p_iter;
	}

	for ( ;p_iter != p_end; ++p_iter)	{
		encoded += '/';
		encoded += UrlEncoder::encode(*p_iter);
	}

	return encoded;
}


string Url::UrlPath::getPathName() const
{
	string path;
	vector<string>::const_iterator p_iter = _pathComponents.begin();
	vector<string>::const_iterator p_end = _pathComponents.end();

	if (p_iter != p_end)	{
		path += *p_iter;
		++p_iter;
	}

	for ( ;p_iter != p_end; ++p_iter)	{
		path += '/';
		path += *p_iter;
	}

	return path;
}


void Url::ParsedUrl::parse(const string& url)
{
	string working(url);

	string::size_type place = working.find('#');
	if (place != string::npos) {
		_fragment = UrlEncoder::decode(working.substr(place + 1));
		working = working.substr(0, place);
	}
	else _fragment.erase();

	place = working.find(':');
	if (!(place == 0 || place == string::npos))	{
		string part(working.substr(0, place));
		if (part.find('/') == string::npos)	{
			_scheme = UrlEncoder::decode(part);
			working = working.substr(place + 1);
		}
		else _scheme.erase();
	}
	else _scheme.erase() ;

	if (working[0] == '/' && working[1] == '/')	{
		place = working.find('/', 2);
		_networkLocation.parse(working.substr(2, place - 2));
		working = place == string::npos ? string() : working.substr(place);
	}
	else _networkLocation = NetworkLocation();

	place = working.find('?');
	if (place != string::npos)	{
		_query = UrlEncoder::decode(working.substr(place + 1));
		working = working.substr(0, place);
	}
	else _query.erase();

	place = working.find(';');
	if (place != string::npos)	{
		_params = UrlEncoder::decode(working.substr(place + 1));
		working = working.substr(0, place);
	}
	else _params.erase();

	_path.parse(working);
}


Url::NVMap Url::ParsedUrl::getQueryParameters() const
{
  NVMap result;
  string working = _query;

  result.clear();
  while (1) {
    if (working.length() == 0) break;
    int idx1 = working.find('=');
    if (idx1 == -1) break;
    string name = working.substr(0, idx1);
    working = working.substr(idx1 + 1);
    int idx2 = working.find('&');
    string value = working.substr(0, idx2);
    working = working.substr(idx2 + 1);
    result[name] = value;
  }
  return result;
}


string Url::ParsedUrl::getEncoded() const
{
	string encoded;

	if (!_scheme.empty())	{
		encoded += UrlEncoder::encode(_scheme);
		encoded += ':';
	}
	string netloc(_networkLocation.getEncoded());
	if (!netloc.empty())	{
		encoded += "//";
		encoded += netloc;
	}
	encoded += _path.getEncoded();
	if (!_params.empty())	{
		encoded += ';';
		encoded += UrlEncoder::encode(_params);
	}
	if (!_query.empty())	{
		encoded += '?';
		encoded += UrlEncoder::encode(_query);
	}
	if (!_fragment.empty())	{
		encoded += '#';
		encoded += UrlEncoder::encode(_fragment);
	}

	return encoded ;
}
