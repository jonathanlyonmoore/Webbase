/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
/*
 * linkBin2Text.cc
 * Converts binary links files into ascii links files
 *
 * Taher H. Haveliwala (taherh@cs.stanford.edu)
 */
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>

int main() {
  unsigned long long i, k;

  unsigned long long src, dst;

  unsigned int cntr = 0;

  if(sizeof(i)!=8) {
    std::cerr << "No long long support...exiting" << std::endl;
    exit(1);
  }
  
  std::cout.fill('0');
  std::vector<unsigned long long int> v;

  while(true) {
    v.clear();
    std::cin.read((char*) &src, sizeof(src)); // Uses endianness of Pita
    if(std::cin.eof()) break;
    if(src == 0) {
      std::cerr << "src was zero in lb2t" << std::endl;
    }
    //    std::cout << std::setw(20) << n;
    std::cin.read((char*) &k, sizeof(k)); 
    //    std::cout << "\t" << std::setw(20) << k;

    // check for failure after reading in source docId and numOutlinks
    // (either read could have caused failure)
    if(std::cin.fail()) {
      std::cerr << "input bad" << std::endl;
      exit(1);
    }

    // If an eof occurs after reading numOutlinks, flag an error if it
    // wasn't equal to 0
    if(std::cin.eof() && k!=0) { 
      std::cerr << "premature input eof" << std::endl;
      exit(1);
    }

    // Loop through the outlinks
    for(i = 0; i < k; i++) {
      if(std::cin.eof()) {
	std::cerr << "premature eof" << std::endl;
	exit(1);
      }
      std::cin.read((char*) &dst, sizeof(dst)); 
      //      std::cout << " " << std::setw(20) << n;
      if(dst != 0) v.push_back(dst);
    }
    // check to see if the previous k reads succeeded
    if(std::cin.fail()) {
      std::cerr << "input failure" << std::endl;
      exit(1);
    }
    //    std::cout << std::endl;

    if(src == 0 || v.size() == 0 || v.size() > 256) continue;

    if(++cntr % 1000 == 0) {
      std::cerr << "Processed: " << cntr << " entries." << std::endl;
    }

    std::cout << std::setw(20) << src;
    std::cout << "\t" << v.size();
    std::vector<unsigned long long int>::iterator iter;
    for(iter = v.begin(); iter != v.end(); iter++) {
      std::cout << " " << *iter;
    }
    std::cout << std::endl;
  }
}



