/*
   The Stanford WebBase Project <webbase@db.stanford.edu>
   Copyright (C) 1999-2002 The Board of Trustees of the
   Leland Stanford Junior University
   
   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License
   as published by the Free Software Foundation; either version 2
   of the License, or (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/
// Convert unsigned to signed docid
// maybe make sure second field is positive
// flags:
// -f check first field (DocID)
// -s check second field for < 0
//    Gary Wesley <gary@db.stanford.edu> 9/1
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <unistd.h>

#define MAXSECONDFIELD  10000000  // for pagelength 
//#define MAXSECONDFIELD  500000000000  // for offset 
#define BOTTOMHASH       - 8439488806233686922
// -10000117293256230   
//-135225284564103792
#define TOPHASH            8439488806233686922
//   10000117293256230
//135225284564103792


int main(int argc, char *argv[])
{ 
  unsigned long long urlhash;
  signed   long long urlhashsigned;

  unsigned long  long  secondField;
  signed   long  long  secondFieldsigned; 
  //signed   long      secondFieldsignedl;

  bool  checkFirstField  = false;
  bool  checkSecondField = false;

  int numbadURLtossed    = 0;
  int numzeroURLtossed   = 0;
  int numbad2ndtossed    = 0;
  int numinspected       = 0;
  int numwritten         = 0;

  int c, errflg = 0;
  
  while ((c = getopt(argc, argv, "fs")) != EOF) {
    switch (c) {
    case 'f':
      checkFirstField = true;
      std::cerr << " checkFirstField ";
      break;
    case 's':
      checkSecondField = true;
      std::cerr << " checkSecondField ";
      break;
    case '?':
      errflg++;
    }
  }
  //char line[40];
  // while( std::cin.getline(line, 40) ){
  while( (std::cin >> urlhash, std::cin >> secondField) &&  
	 (  numbadURLtossed < 3000 ) ){
    
    urlhashsigned = (signed long long ) urlhash;
    numinspected++;
    if( ! checkFirstField ||
	//urlhashsigned != 0  && 
	(urlhashsigned > BOTTOMHASH && urlhashsigned < TOPHASH )){  
      std::cout.width( 20 );
      //cout.fill(' ');
      
      secondFieldsigned =  (signed long  long)  secondField;
      //secondFieldsignedl  =  (signed      long)  secondField;
      
      if(! checkSecondField ||
	 ( secondFieldsigned >= 0 
	   &&  secondFieldsigned < MAXSECONDFIELD // size check
	   )){	
	std::cout << urlhashsigned << "\t"; 
	//cout.width( 15 );cout.fill('0');
	std::cout << secondFieldsigned << std::endl; numwritten++;
      }
      else{  // yes we check it
	/*if( secondFieldsigned < 0 ){
	  if(  numbad2ndtossed == 0) std::cerr << "@" << numinspected ;
	  numbad2ndtossed++;
	  std::cerr << "<0:" << secondFieldsigned;
	  }
	else {
	*/
	if( secondFieldsigned > MAXSECONDFIELD ) {
	    // try to resync
	    char buf[60]; 
	    //std::cerr << "!" << secondFieldsigned;
	    if( numbad2ndtossed == 0) std::cerr  << secondFieldsigned << "\n+@" << numinspected ;
	    numbad2ndtossed++;
	    std::cin.getline(buf,60);
	    numbad2ndtossed++;
	    std::cin.getline(buf,60);
	  }	  
	  else {
	    std::cout <<  urlhashsigned << "\t0\n"; 
	    numwritten++;
	  }
      }
      //}	
    }
    else 
      if( checkFirstField ){
	if( urlhashsigned == 0 ){
	  //std::cerr << "0";
	  numzeroURLtossed++;
	}
	//	else if( urlhashsigned < 100000000000 && urlhashsigned > 0 ) {
	else if(
		//( urlhash  < 100000000000 )
		//|  
		(urlhashsigned < BOTTOMHASH || urlhashsigned > TOPHASH )
		) {
	  std::cerr << ":" << urlhashsigned;
	  if(  numbadURLtossed == 0) std::cerr << "\n-@" << numinspected ;
	  
	  // try to resync
	  char buf[60]; 
	  std::cin.getline(buf,60);
	  numbadURLtossed++; 
	}
	else{ 
	  numbadURLtossed++;
	  std::cerr << "?" << urlhashsigned <<  " " << BOTTOMHASH << " " << TOPHASH;
	  // should never hit this!
	}
      }
      else std::cerr << ";";
    
  }
  std::cerr << std::endl;
  if( checkFirstField ){ 
    std::cerr << "rejected: " << numbadURLtossed << " bad and ";
    std::cerr << numzeroURLtossed << " 0-urlhashs out of " ;
  }
  
  std::cerr << numinspected << " items ";
  
  if( checkFirstField ){
    std::cerr << "... which is ";
    std::cerr << std::setprecision(5) <<  
      ((float)(numbadURLtossed + numzeroURLtossed) / 
       (float) numinspected) * 100.0 << "%";
  }
  
  if( checkSecondField ){
    std::cerr << std::setprecision(3) <<  " rejected 2nd field: " << numbad2ndtossed;
    std::cerr << "/" <<  numinspected ;
    std::cerr << "... which is ";
    std::cerr << std::setprecision(5) <<  
      ((float)numbad2ndtossed  / 
       (float) numinspected) * 100.0 << "%";
    std::cerr << "... total losses ";
    std::cerr << std::setprecision(5) <<  
      ((float)(numbadURLtossed + numzeroURLtossed + numbad2ndtossed) / 
       (float) numinspected) * 100.0 << "%";
  }
  
  std::cerr << " wrote " << numwritten << std::endl;
  if ( numbadURLtossed > 1000 ) std::cerr << "\n<<<<<<<<\n<<<<<<<<\n"  << std::endl; ;
  return numwritten;
}
