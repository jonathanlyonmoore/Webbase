#!/usr/bin/perl
# 
# A preprocessor that takes a list of hostnames, and generates a crawl list
# for the crawler.
# DNS lookup

use warnings;
#use strict;

use Socket;
#$COMPAT_VER_3 = 1;
#$COMPAT_VER_3 = 1;
my  $threshold = 3;
if($threshold > 0){
  print STDERR "Only resolving sites with pagerank > $threshold\n";}

$| = 1;
my $cntr = 0;
while(<>) {
#  print STDERR "$_";
  my @line = split;
  my $pagerank = pop @line;
 
  if(defined $pagerank and  ($pagerank =~ /^-?\d/o) and $pagerank > $threshold ){
    if( $line[0] ){
      my ($name,$aliases,$addrtype,$length,@addrs) = gethostbyname($line[0]);
    print "original: @line\npagerank: $pagerank\nname: $name\naliases: $aliases\naddrtype: $addrtype\nlength: $length\naddrs: " . join(" ", (map {inet_ntoa($_)} @addrs)) . "\n\n" if $name;
    }
  }
  
  print STDERR "." if(++$cntr % 1000 == 0);
}
