#!/usr/bin/perl
#
# runhandlers | ./extract-hosts.pl > hosts.txt
#
# Enable CATLINKS in the conf file for runhandlers
#
# will not work with 5.8.0 unless you setenv LANG en_US

#use warnings;
#use strict;
#use diagnostics;
#use bytes;
use URI;

$COMPAT_VER_3 = 1;
printf STDERR "Try COMPAT_VER_3\n";

my $quit = 0;

$SIG{QUIT} = $SIG{INT} = sub { $quit = 1; print STDERR "Quit requested...\n"};

my $cnt = 0;

my %hostnames;
my $uris = 0;
while(<>) {
  last if $quit;
  chomp;
  if(/^http/io) {
    eval {
      my $uri = URI->new($_)->canonical;#printf $uri ."|" .  $uri->scheme . "\n";
      $hostnames{$uri->host}++ if ($uri and $uri->scheme eq "http");
      #print STDERR $uri->host . " " if( $uri and $uri->scheme eq "http");
      $uris++ if ($uri and $uri->scheme eq "http");
    };
    if($@) {
      print STDERR "Error: $@\n";
    }
  }
  print STDERR "cnt: $cnt $uris\n"  if(++$cnt % 100000 == 0);
  output() if(++$cnt % 10000000 == 0);
}


output();

sub output {
  print STDERR "count: $cnt $uris\n";
  foreach my $hostname (keys %hostnames) {
    #strip garbage
    (my $final, my $trash) = split(/ |<|\"|>|:|&|\)|,|;|\'/o, $hostname, 2 );
    #if(defined($trash) ){printf STDERR "discarded $trash|from $hostname|";}
    #print "$final\t$hostnames{$hostname}\n";
    #if( $final and ($hostnames{$hostname} > 1)){print "$final\t$hostnames{$hostname}\n";}#else{printf STDERR "blank url $final";}
    if( $final ){print "$final\t$hostnames{$hostname}\n";}#else{printf STDERR "blank url $final";}
  }
  %hostnames = ();
}
