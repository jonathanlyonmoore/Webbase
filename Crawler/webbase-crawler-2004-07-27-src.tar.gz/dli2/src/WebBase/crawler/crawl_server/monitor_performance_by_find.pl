#!/usr/bin/perl -w
# display how many bytes written per minute/hr/day by crawlers
#  path  = which path to monitor
#  sleep = minutes between samples
#  loops = how many times through 0=just report on used, no rate info

# NOTES: this is only practical when < 100GB in the path (??)
#   more accurate than monitor_performance_by_df.pl
#   only reports the one machine run on
#   Gary Wesley <gary@db.stanford.edu> 08/03
require 5.003; # least we have tested on
if(@ARGV < 1) { printf "path sleep loops\n"; exit 2; }

$data = $ARGV[0];

if(@ARGV < 2) { 
  $sleepTime = 0;
}
else {
  $sleepTime = $ARGV[1];
}
if(@ARGV < 3) { 
  $loops = 0;
}
else {
  $loops = $ARGV[2];
}

# a lot of spurious errors come out otherwise
open(STDERR, "> log/errlog") || die $!; 
#/dev/sda             1688891464 132050768 1539682552   8% /lfs/1
my $start;
my $i;
my $begin_time ;
my $warned100GB = 0;
my $warned50GB = 0;
my $warned20GB = 0;
my $warned10GB = 0;
my $warnedGB = 0;
my $warned100MB = 0;
my $lfs_path = "/lfs/1";

$start = `nice find $data -type d | nice egrep '_repository_/[text|image|unknown]' | xargs du -s --block-size=1024 | leaftot.pl` ;
#printf $start;
(undef, my  $start1used, undef , undef)  = split(/[\s\t]+/, $start); # parse line into tokens
$start1used =~ s/MB/00/;

if($loops == 0){ # just report
  printf "%5.9f GB cmprsd ",$start1used / 1024 ;
}
#figure out is /lfs/1 or /lfs/2 are the main disk
$start = `df /lfs/2 | tail -n 1`; 
(my $path,my $total, undef, my $remaining, undef) = split(/[\s\t]+/, $start);

if($total > 400000000){ # 400 GB
       $lfs_path = "/lfs/2"; }
else { $lfs_path = "/lfs/1"; }

for($i = 0; $i < $loops ; $i++){
  #system('perl status_all.pl | grep Sit');
  
  $start = `df $lfs_path | tail -n 1`;
  
  (my $path,my $total, undef, my $remaining, undef) = split(/[\s\t]+/, $start); # parse line into tokens
  if( $remaining < 100000000 ){ 
    if(   ! $warned100GB){printf "ADVISORY !!!!!!!!!!!! < 100 GB left!!!!!!" . $remaining . " on " .  $path . "\n";$warned100GB = 1;}
  }  
  if( $remaining < 50000000 ){ 
    if(  ! $warned50GB){ printf "CAUTIONGARY !!!!!!!!!!!! < 50 GB left!!!!!!" . $remaining . " on " .  $path . "\n";$warned50GB = 1;$warned100GB = 1;}
  }
  if( $remaining < 20000000 ){ 
    if(  ! warned20GB){ printf "CAUTIONARY !!!!!!!!!!!! < 20 GB left!!!!!!" . $remaining . " on " .  $path . "\n";$warned20GB = 1;$warned50GB = 1;$warned100GB = 1;}
  }
  if( $remaining < 10000000 ){ 
    if(! $warned10GB ){ printf "CAUTION !!!!!!!!!!!! < 10 GB left!!!!!!!!!!!!!!!!!!!!!!!!!!!" . $remaining . " on " .  $path . "\n";$warned10GB = 1;$warned20GB = 1;$warned50GB = 1;$warned100GB = 1;}
  }  
  if( $remaining < 1000000 ){ 
    if(!$warnedGB ){printf "WARNING !!!!!!!!!!!! < 1 GB left!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" . $remaining . " on " .  $path . "\n";$warnedGB = 1;$warned10GB = 1;$warned20GB = 1;$warned50GB = 1;$warned100GB = 1;}
  }	 
  if( $remaining < 100000  ){ 
    if( !$warned100MB){ printf "DANGER !!!!!!!!!!!! < 100 MB left!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" . $remaining . " on " .  $path . "\n";$warned100MB = 1;}
  }
  #printf "find $data -type d | egrep \'_repository_/text\$\' | xargs du -s --block-size=1024 | ~webbase/dli2/src/WebBase/crawler/remote_crawl_binaries//leaftot.pl\n";
  $begin_time =  time();

  sleep $sleepTime * 60;
  
  my $end  = `nice find $data -type d | nice egrep '_repository_/[text|image|unknown]' | xargs du -s --block-size=1024 | leaftot.pl` ;
  #printf $end;
  
  (undef, my  $end1used, undef , undef )  = split(/[\s\t]+/, $end); # parse line into tokens
$end1used =~ s/MB/00/;

  my $end_time =  time();
  my $elapsed_seconds = $end_time - $begin_time;
  
  my $used = $end1used -  $start1used ;
    
  #printf "$end1used minus  $start1used equals $used \n";
  
  my $gbwritten = ( $end1used /1024  );

  #printf $used . "MB in " .  $elapsed_seconds / 60 . " minutes\n";
  my $mbmin =  ($used / $elapsed_seconds) * 60  ;  
  my $mbhr =  $mbmin * 60;
  my $gbhr =  $mbhr / 1024;
  my $gbday = ( $mbhr * 24 ) / 1024;
  my $gbmonth = $gbday * 30;
  my $tbmonth = $gbmonth / 1024;
  $tod =  `date +%H`;
  if( $tod == "00"){printf  `date +%D` ;}
  printf "%5.3f GB: %4.3f GB/hr %3.0f GB/day %2.1f TB/mo cmprsd ",
    $gbwritten, $gbhr ,      $gbday ,    $tbmonth;
  $start1used = $end1used;
  
  #my $line = `ps -eaf | grep "crawl_server -id " | wc -l`;
  if( $sleepTime > 4){ system('perl sitetot.pl 0 49'); }
  printf `date +%H:%M`;
}
exit 0;
